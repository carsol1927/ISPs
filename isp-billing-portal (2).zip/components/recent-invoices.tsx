import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export function RecentInvoices() {
  return (
    <div className="space-y-8">
      {invoices.map((invoice) => (
        <div key={invoice.id} className="flex items-center">
          <Avatar className="h-9 w-9 mr-3">
            <AvatarImage src={`/placeholder.svg?height=36&width=36`} alt={`@${invoice.customer}`} />
            <AvatarFallback>{invoice.customer.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium leading-none">{invoice.customer}</p>
            <p className="text-sm text-muted-foreground">{invoice.email}</p>
          </div>
          <div className="ml-auto text-right">
            <p className="text-sm font-medium">${invoice.amount}</p>
            <Badge variant={invoice.status === "Paid" ? "outline" : "secondary"} className="mt-1">
              {invoice.status}
            </Badge>
          </div>
        </div>
      ))}
    </div>
  )
}

const invoices = [
  {
    id: "INV001",
    customer: "Alex Johnson",
    email: "alex@example.com",
    amount: "429.99",
    status: "Paid",
  },
  {
    id: "INV002",
    customer: "Sarah Williams",
    email: "sarah@example.com",
    amount: "829.99",
    status: "Pending",
  },
  {
    id: "INV003",
    customer: "Michael Brown",
    email: "michael@example.com",
    amount: "129.99",
    status: "Paid",
  },
  {
    id: "INV004",
    customer: "Jessica Davis",
    email: "jessica@example.com",
    amount: "329.99",
    status: "Overdue",
  },
  {
    id: "INV005",
    customer: "David Miller",
    email: "david@example.com",
    amount: "599.99",
    status: "Paid",
  },
]
