"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"

const data = [
  { time: "00:00", hotspot: 320, pppoe: 400, dataplan: 240 },
  { time: "02:00", hotspot: 300, pppoe: 398, dataplan: 220 },
  { time: "04:00", hotspot: 280, pppoe: 390, dataplan: 200 },
  { time: "06:00", hotspot: 340, pppoe: 420, dataplan: 210 },
  { time: "08:00", hotspot: 520, pppoe: 480, dataplan: 250 },
  { time: "10:00", hotspot: 650, pppoe: 520, dataplan: 280 },
  { time: "12:00", hotspot: 700, pppoe: 550, dataplan: 300 },
  { time: "14:00", hotspot: 720, pppoe: 600, dataplan: 320 },
  { time: "16:00", hotspot: 800, pppoe: 650, dataplan: 340 },
  { time: "18:00", hotspot: 830, pppoe: 680, dataplan: 350 },
  { time: "20:00", hotspot: 845, pppoe: 723, dataplan: 324 },
  { time: "22:00", hotspot: 780, pppoe: 700, dataplan: 310 },
]

export function ActiveUserStats() {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="hotspot" stroke="#8884d8" activeDot={{ r: 8 }} name="Hotspot Users" />
          <Line type="monotone" dataKey="pppoe" stroke="#82ca9d" name="PPPoE Users" />
          <Line type="monotone" dataKey="dataplan" stroke="#ffc658" name="Data Plan Users" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
