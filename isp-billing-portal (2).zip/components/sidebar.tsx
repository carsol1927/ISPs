"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  Users,
  Ticket,
  UserPlus,
  DollarSign,
  Package,
  CreditCard,
  Tag,
  Receipt,
  Megaphone,
  MessageCircle,
  Smartphone,
  Router,
  HardDrive,
  LayoutDashboard,
  BarChart,
  Settings,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"

// Mock data for counters - in a real app, this would come from an API
const counters = {
  activeUsers: 1892,
  users: 2350,
  tickets: 42,
  leads: 78,
  payments: 156,
  packages: 9,
  vouchers: 1245,
  expenses: 34,
  campaigns: 5,
  sms: 8500,
  mikrotiks: 24,
  equipment: 120,
}

type SidebarItem = {
  title: string
  icon: React.ElementType
  href: string
  counter?: number
}

type SidebarGroup = {
  title: string
  items: SidebarItem[]
}

const sidebarGroups: SidebarGroup[] = [
  {
    title: "Overview",
    items: [
      {
        title: "Dashboard",
        icon: LayoutDashboard,
        href: "/",
      },
      {
        title: "Reports",
        icon: BarChart,
        href: "/reports",
      },
    ],
  },
  {
    title: "Users",
    items: [
      {
        title: "Active Users",
        icon: Users,
        href: "/active-users",
        counter: counters.activeUsers,
      },
      {
        title: "Users",
        icon: Users,
        href: "/customers",
        counter: counters.users,
      },
      {
        title: "Leads",
        icon: UserPlus,
        href: "/leads",
        counter: counters.leads,
      },
    ],
  },
  {
    title: "Support",
    items: [
      {
        title: "Tickets",
        icon: Ticket,
        href: "/tickets",
        counter: counters.tickets,
      },
    ],
  },
  {
    title: "Billing",
    items: [
      {
        title: "Finance",
        icon: DollarSign,
        href: "/billing",
      },
      {
        title: "Packages",
        icon: Package,
        href: "/packages",
        counter: counters.packages,
      },
      {
        title: "Payments",
        icon: CreditCard,
        href: "/payments",
        counter: counters.payments,
      },
      {
        title: "Vouchers",
        icon: Tag,
        href: "/vouchers",
        counter: counters.vouchers,
      },
      {
        title: "Expenses",
        icon: Receipt,
        href: "/expenses",
        counter: counters.expenses,
      },
    ],
  },
  {
    title: "Communication",
    items: [
      {
        title: "Campaigns",
        icon: Megaphone,
        href: "/campaigns",
        counter: counters.campaigns,
      },
      {
        title: "SMS",
        icon: MessageCircle,
        href: "/sms",
        counter: counters.sms,
      },
    ],
  },
  {
    title: "Infrastructure",
    items: [
      {
        title: "Devices",
        icon: Smartphone,
        href: "/devices",
      },
      {
        title: "Mikrotiks",
        icon: Router,
        href: "/mikrotik",
        counter: counters.mikrotiks,
      },
      {
        title: "Equipment",
        icon: HardDrive,
        href: "/services",
        counter: counters.equipment,
      },
    ],
  },
  {
    title: "System",
    items: [
      {
        title: "Settings",
        icon: Settings,
        href: "/settings",
      },
    ],
  },
]

export function Sidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  // Check for localStorage preference on mount
  useEffect(() => {
    const savedState = localStorage.getItem("sidebarCollapsed")
    if (savedState !== null) {
      setCollapsed(savedState === "true")
    }

    // Add event listener for mouse movement
    // const handleMouseMove = (e: MouseEvent) => {
    //   if (e.clientX <= (collapsed ? 64 : 256)) {
    //     setCollapsed(false)
    //   } else if (!collapsed) {
    //     setCollapsed(true)
    //   }
    // }

    // We don't need this event listener since we're using the overlay approach
    // window.addEventListener("mousemove", handleMouseMove)
    // return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  // Save preference when changed
  useEffect(() => {
    localStorage.setItem("sidebarCollapsed", String(collapsed))
  }, [collapsed])

  return (
    <>
      <div
        className={cn(
          "flex h-screen flex-col border-r bg-background transition-width duration-300 fixed z-40",
          collapsed ? "w-16" : "w-64",
        )}
        onMouseEnter={() => setCollapsed(false)}
      >
        <div className="flex h-14 items-center justify-between border-b px-3">
          <div className={cn("flex items-center", collapsed && "justify-center w-full")}>
            {!collapsed && <span className="text-lg font-semibold">ISP Admin</span>}
            {collapsed && <Router className="h-7 w-7" />}
          </div>
        </div>

        <div className="flex-1 overflow-auto py-2">
          {sidebarGroups.map((group, groupIndex) => (
            <div key={groupIndex} className="px-3 py-2">
              {!collapsed && (
                <h3 className="mb-2 text-xs font-semibold uppercase text-muted-foreground">{group.title}</h3>
              )}
              <ul className="space-y-1">
                {group.items.map((item, itemIndex) => {
                  const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`)

                  return (
                    <li key={itemIndex}>
                      <Link
                        href={item.href}
                        className={cn(
                          "flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors",
                          isActive ? "bg-primary text-primary-foreground" : "hover:bg-muted",
                          collapsed && "justify-center px-2 py-3",
                        )}
                      >
                        <item.icon className={cn(collapsed ? "h-6 w-6" : "h-5 w-5 mr-2")} />
                        {!collapsed ? (
                          <>
                            <span className="flex-1 truncate">{item.title}</span>
                            {item.counter !== undefined && (
                              <Badge variant="outline" className="ml-auto">
                                {item.counter > 999 ? `${Math.floor(item.counter / 1000)}k` : item.counter}
                              </Badge>
                            )}
                          </>
                        ) : null}
                      </Link>
                    </li>
                  )
                })}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {!collapsed && <div className="fixed inset-0 bg-transparent z-30" onMouseEnter={() => setCollapsed(true)} />}

      <div className={collapsed ? "w-16" : "w-64"} />
    </>
  )
}
