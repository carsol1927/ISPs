import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  MessageSquare,
  AlertCircle,
  CheckCircle2,
  Clock,
  Users,
  Wifi,
  CreditCard,
  HardDrive,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"

export default function TicketsPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Support Tickets</h1>
          <div className="flex items-center gap-2">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Ticket
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tickets</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">128</div>
              <p className="text-xs text-muted-foreground">+12 from last week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Open Tickets</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">42</div>
              <p className="text-xs text-muted-foreground">+8 from yesterday</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resolved Tickets</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">86</div>
              <p className="text-xs text-muted-foreground">+24 from last week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Response Time</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3.2 hrs</div>
              <p className="text-xs text-muted-foreground">-0.5 hrs from last week</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Tickets</TabsTrigger>
            <TabsTrigger value="open">Open</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="resolved">Resolved</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search tickets..." className="w-full min-w-[260px] pl-8" />
                </div>
                <Button variant="outline" size="sm" className="h-9">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
            </div>

            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Ticket ID</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tickets.map((ticket) => (
                    <TableRow key={ticket.id}>
                      <TableCell className="font-medium">{ticket.id}</TableCell>
                      <TableCell>{ticket.subject}</TableCell>
                      <TableCell>{ticket.customer}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {ticket.category === "Technical" ? (
                            <Wifi className="h-4 w-4 text-blue-500" />
                          ) : ticket.category === "Billing" ? (
                            <CreditCard className="h-4 w-4 text-green-500" />
                          ) : ticket.category === "Account" ? (
                            <Users className="h-4 w-4 text-purple-500" />
                          ) : (
                            <HardDrive className="h-4 w-4 text-orange-500" />
                          )}
                          {ticket.category}
                        </div>
                      </TableCell>
                      <TableCell>{ticket.date}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            ticket.status === "Open"
                              ? "destructive"
                              : ticket.status === "Pending"
                                ? "default"
                                : "outline"
                          }
                        >
                          {ticket.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            ticket.priority === "High"
                              ? "bg-red-100 text-red-800 border-red-200"
                              : ticket.priority === "Medium"
                                ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                                : "bg-green-100 text-green-800 border-green-200"
                          }
                        >
                          {ticket.priority}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem>View details</DropdownMenuItem>
                            <DropdownMenuItem>Assign ticket</DropdownMenuItem>
                            <DropdownMenuItem>Change priority</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>Mark as resolved</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious href="#" />
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">1</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#" isActive>
                    2
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">3</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
                <PaginationItem>
                  <PaginationNext href="#" />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </TabsContent>

          <TabsContent value="open" className="space-y-4">
            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Ticket ID</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tickets
                    .filter((ticket) => ticket.status === "Open")
                    .map((ticket) => (
                      <TableRow key={ticket.id}>
                        <TableCell className="font-medium">{ticket.id}</TableCell>
                        <TableCell>{ticket.subject}</TableCell>
                        <TableCell>{ticket.customer}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {ticket.category === "Technical" ? (
                              <Wifi className="h-4 w-4 text-blue-500" />
                            ) : ticket.category === "Billing" ? (
                              <CreditCard className="h-4 w-4 text-green-500" />
                            ) : ticket.category === "Account" ? (
                              <Users className="h-4 w-4 text-purple-500" />
                            ) : (
                              <HardDrive className="h-4 w-4 text-orange-500" />
                            )}
                            {ticket.category}
                          </div>
                        </TableCell>
                        <TableCell>{ticket.date}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              ticket.priority === "High"
                                ? "bg-red-100 text-red-800 border-red-200"
                                : ticket.priority === "Medium"
                                  ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                                  : "bg-green-100 text-green-800 border-green-200"
                            }
                          >
                            {ticket.priority}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="pending" className="space-y-4">
            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Ticket ID</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tickets
                    .filter((ticket) => ticket.status === "Pending")
                    .map((ticket) => (
                      <TableRow key={ticket.id}>
                        <TableCell className="font-medium">{ticket.id}</TableCell>
                        <TableCell>{ticket.subject}</TableCell>
                        <TableCell>{ticket.customer}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {ticket.category === "Technical" ? (
                              <Wifi className="h-4 w-4 text-blue-500" />
                            ) : ticket.category === "Billing" ? (
                              <CreditCard className="h-4 w-4 text-green-500" />
                            ) : ticket.category === "Account" ? (
                              <Users className="h-4 w-4 text-purple-500" />
                            ) : (
                              <HardDrive className="h-4 w-4 text-orange-500" />
                            )}
                            {ticket.category}
                          </div>
                        </TableCell>
                        <TableCell>{ticket.date}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              ticket.priority === "High"
                                ? "bg-red-100 text-red-800 border-red-200"
                                : ticket.priority === "Medium"
                                  ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                                  : "bg-green-100 text-green-800 border-green-200"
                            }
                          >
                            {ticket.priority}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="resolved" className="space-y-4">
            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Ticket ID</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Resolved Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tickets
                    .filter((ticket) => ticket.status === "Resolved")
                    .map((ticket) => (
                      <TableRow key={ticket.id}>
                        <TableCell className="font-medium">{ticket.id}</TableCell>
                        <TableCell>{ticket.subject}</TableCell>
                        <TableCell>{ticket.customer}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {ticket.category === "Technical" ? (
                              <Wifi className="h-4 w-4 text-blue-500" />
                            ) : ticket.category === "Billing" ? (
                              <CreditCard className="h-4 w-4 text-green-500" />
                            ) : ticket.category === "Account" ? (
                              <Users className="h-4 w-4 text-purple-500" />
                            ) : (
                              <HardDrive className="h-4 w-4 text-orange-500" />
                            )}
                            {ticket.category}
                          </div>
                        </TableCell>
                        <TableCell>{ticket.date}</TableCell>
                        <TableCell>{ticket.resolvedDate || "-"}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

const tickets = [
  {
    id: "TKT-001",
    subject: "Internet connection issues",
    customer: "John Smith",
    category: "Technical",
    date: "2023-05-18",
    status: "Open",
    priority: "High",
    resolvedDate: null,
  },
  {
    id: "TKT-002",
    subject: "Billing inquiry",
    customer: "Emily Johnson",
    category: "Billing",
    date: "2023-05-17",
    status: "Pending",
    priority: "Medium",
    resolvedDate: null,
  },
  {
    id: "TKT-003",
    subject: "Password reset request",
    customer: "Michael Williams",
    category: "Account",
    date: "2023-05-16",
    status: "Resolved",
    priority: "Low",
    resolvedDate: "2023-05-16",
  },
  {
    id: "TKT-004",
    subject: "Slow internet speed",
    customer: "Jessica Brown",
    category: "Technical",
    date: "2023-05-15",
    status: "Open",
    priority: "Medium",
    resolvedDate: null,
  },
  {
    id: "TKT-005",
    subject: "Package upgrade request",
    customer: "David Miller",
    category: "Service",
    date: "2023-05-14",
    status: "Pending",
    priority: "Low",
    resolvedDate: null,
  },
  {
    id: "TKT-006",
    subject: "Router configuration issue",
    customer: "Sarah Davis",
    category: "Technical",
    date: "2023-05-13",
    status: "Open",
    priority: "High",
    resolvedDate: null,
  },
  {
    id: "TKT-007",
    subject: "Payment failed",
    customer: "Robert Wilson",
    category: "Billing",
    date: "2023-05-12",
    status: "Resolved",
    priority: "High",
    resolvedDate: "2023-05-13",
  },
  {
    id: "TKT-008",
    subject: "Service outage report",
    customer: "Jennifer Taylor",
    category: "Technical",
    date: "2023-05-11",
    status: "Resolved",
    priority: "High",
    resolvedDate: "2023-05-12",
  },
  {
    id: "TKT-009",
    subject: "Account cancellation request",
    customer: "Thomas Anderson",
    category: "Account",
    date: "2023-05-10",
    status: "Pending",
    priority: "Medium",
    resolvedDate: null,
  },
  {
    id: "TKT-010",
    subject: "Data usage inquiry",
    customer: "Lisa Martinez",
    category: "Service",
    date: "2023-05-09",
    status: "Resolved",
    priority: "Low",
    resolvedDate: "2023-05-10",
  },
]
