import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Search, Filter, MessageSquare, Send, Users, CheckCircle2 } from "lucide-react"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SMSPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">SMS Notifications</h1>
          <div className="flex items-center gap-2">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New SMS Campaign
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total SMS Sent</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12,845</div>
              <p className="text-xs text-muted-foreground">+1,234 from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Delivery Rate</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">98.5%</div>
              <p className="text-xs text-muted-foreground">+0.5% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Campaigns</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5</div>
              <p className="text-xs text-muted-foreground">+2 from last week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">SMS Credits</CardTitle>
              <Send className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">8,500</div>
              <p className="text-xs text-muted-foreground">-1,500 from last week</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="compose" className="space-y-4">
          <TabsList>
            <TabsTrigger value="compose">Compose SMS</TabsTrigger>
            <TabsTrigger value="history">SMS History</TabsTrigger>
            <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="compose" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Compose New SMS</CardTitle>
                <CardDescription>Send SMS notifications to customers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Recipients</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select recipient type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Customers</SelectItem>
                        <SelectItem value="active">Active Customers</SelectItem>
                        <SelectItem value="inactive">Inactive Customers</SelectItem>
                        <SelectItem value="overdue">Customers with Overdue Payments</SelectItem>
                        <SelectItem value="custom">Custom Selection</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Message Template</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a template or create new" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="payment">Payment Reminder</SelectItem>
                        <SelectItem value="welcome">Welcome Message</SelectItem>
                        <SelectItem value="outage">Service Outage</SelectItem>
                        <SelectItem value="promotion">Promotion</SelectItem>
                        <SelectItem value="custom">Custom Message</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Message</label>
                    <Textarea
                      placeholder="Type your message here. Use {name} for customer name, {dueDate} for due date, etc."
                      className="min-h-[120px]"
                    />
                    <p className="text-xs text-muted-foreground">
                      Characters: 0/160 | Messages: 1 | Estimated cost: $0.00
                    </p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Schedule (Optional)</label>
                    <div className="flex gap-2">
                      <Input type="date" className="w-full" />
                      <Input type="time" className="w-full" />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button variant="outline">Preview</Button>
                    <Button>Send SMS</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search messages..." className="w-full min-w-[260px] pl-8" />
                </div>
                <Button variant="outline" size="sm" className="h-9">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
            </div>

            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">ID</TableHead>
                    <TableHead>Recipient</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Sent Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {smsHistory.map((sms) => (
                    <TableRow key={sms.id}>
                      <TableCell className="font-medium">{sms.id}</TableCell>
                      <TableCell>{sms.recipient}</TableCell>
                      <TableCell className="max-w-[300px] truncate">{sms.message}</TableCell>
                      <TableCell>{sms.sentDate}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            sms.status === "Delivered"
                              ? "outline"
                              : sms.status === "Failed"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {sms.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious href="#" />
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">1</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#" isActive>
                    2
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">3</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
                <PaginationItem>
                  <PaginationNext href="#" />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </TabsContent>

          <TabsContent value="campaigns" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {smsCampaigns.map((campaign) => (
                <Card key={campaign.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{campaign.name}</CardTitle>
                        <CardDescription>{campaign.description}</CardDescription>
                      </div>
                      <Badge
                        variant={
                          campaign.status === "Active"
                            ? "outline"
                            : campaign.status === "Completed"
                              ? "secondary"
                              : "default"
                        }
                      >
                        {campaign.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Recipients:</span>
                        <span>{campaign.recipients}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Sent:</span>
                        <span>{campaign.sent}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Delivered:</span>
                        <span>{campaign.delivered}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Start Date:</span>
                        <span>{campaign.startDate}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">End Date:</span>
                        <span>{campaign.endDate || "Ongoing"}</span>
                      </div>
                      <div className="flex justify-end space-x-2 pt-2">
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                        {campaign.status === "Active" && (
                          <Button variant="destructive" size="sm">
                            Stop
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="templates" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium">SMS Templates</h2>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Template
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {smsTemplates.map((template) => (
                <Card key={template.id}>
                  <CardHeader>
                    <CardTitle>{template.name}</CardTitle>
                    <CardDescription>{template.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="rounded-md bg-muted p-3 text-sm">{template.content}</div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Last Used:</span>
                        <span>{template.lastUsed}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Usage Count:</span>
                        <span>{template.usageCount}</span>
                      </div>
                      <div className="flex justify-end space-x-2 pt-2">
                        <Button variant="outline" size="sm">
                          Edit
                        </Button>
                        <Button variant="ghost" size="sm">
                          Use
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

const smsHistory = [
  {
    id: "SMS-001",
    recipient: "John Smith (+1 555-123-4567)",
    message:
      "Dear John, your payment of $129.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Delivered",
  },
  {
    id: "SMS-002",
    recipient: "Emily Johnson (+1 555-234-5678)",
    message:
      "Dear Emily, your payment of $89.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Delivered",
  },
  {
    id: "SMS-003",
    recipient: "Michael Williams (+1 555-345-6789)",
    message:
      "Dear Michael, your payment of $59.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Failed",
  },
  {
    id: "SMS-004",
    recipient: "Jessica Brown (+1 555-456-7890)",
    message:
      "Dear Jessica, your payment of $99.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Delivered",
  },
  {
    id: "SMS-005",
    recipient: "David Miller (+1 555-567-8901)",
    message:
      "Dear David, your payment of $199.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Pending",
  },
  {
    id: "SMS-006",
    recipient: "Sarah Davis (+1 555-678-9012)",
    message:
      "Dear Sarah, your payment of $79.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Delivered",
  },
  {
    id: "SMS-007",
    recipient: "Robert Wilson (+1 555-789-0123)",
    message:
      "Dear Robert, your payment of $129.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Delivered",
  },
  {
    id: "SMS-008",
    recipient: "Jennifer Taylor (+1 555-890-1234)",
    message:
      "Dear Jennifer, your payment of $49.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Failed",
  },
  {
    id: "SMS-009",
    recipient: "Thomas Anderson (+1 555-901-2345)",
    message:
      "Dear Thomas, your payment of $149.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Delivered",
  },
  {
    id: "SMS-010",
    recipient: "Lisa Martinez (+1 555-012-3456)",
    message:
      "Dear Lisa, your payment of $69.99 is due on May 15, 2023. Please ensure timely payment to avoid service interruption. Thank you!",
    sentDate: "2023-05-10 14:30",
    status: "Pending",
  },
]

const smsCampaigns = [
  {
    id: 1,
    name: "May Payment Reminder",
    description: "Payment reminder for May invoices",
    status: "Active",
    recipients: 1250,
    sent: 1250,
    delivered: 1230,
    startDate: "2023-05-10",
    endDate: null,
  },
  {
    id: 2,
    name: "Service Upgrade Promotion",
    description: "Promotion for existing customers to upgrade their service plans",
    status: "Active",
    recipients: 850,
    sent: 850,
    delivered: 840,
    startDate: "2023-05-05",
    endDate: "2023-05-20",
  },
  {
    id: 3,
    name: "Network Maintenance Notice",
    description: "Notice about scheduled network maintenance",
    status: "Completed",
    recipients: 2350,
    sent: 2350,
    delivered: 2320,
    startDate: "2023-04-25",
    endDate: "2023-04-25",
  },
  {
    id: 4,
    name: "Welcome New Customers",
    description: "Welcome message for new customers",
    status: "Active",
    recipients: 180,
    sent: 180,
    delivered: 178,
    startDate: "2023-05-01",
    endDate: null,
  },
  {
    id: 5,
    name: "Service Outage Alert",
    description: "Alert about service outage in downtown area",
    status: "Completed",
    recipients: 450,
    sent: 450,
    delivered: 445,
    startDate: "2023-05-08",
    endDate: "2023-05-08",
  },
]

const smsTemplates = [
  {
    id: 1,
    name: "Payment Reminder",
    description: "Template for payment reminders",
    content:
      "Dear {name}, your payment of ${amount} is due on {dueDate}. Please ensure timely payment to avoid service interruption. Thank you!",
    lastUsed: "2023-05-10",
    usageCount: 2350,
  },
  {
    id: 2,
    name: "Welcome Message",
    description: "Template for welcoming new customers",
    content:
      "Welcome to our ISP services, {name}! Your account has been activated. For support, call us at (555) 123-4567 or email support@isp.com.",
    lastUsed: "2023-05-01",
    usageCount: 180,
  },
  {
    id: 3,
    name: "Service Outage",
    description: "Template for service outage notifications",
    content:
      "Dear {name}, we're experiencing a service outage in your area. Our team is working to resolve it. Estimated resolution time: {estimatedTime}. We apologize for the inconvenience.",
    lastUsed: "2023-05-08",
    usageCount: 450,
  },
  {
    id: 4,
    name: "Promotion",
    description: "Template for promotional messages",
    content:
      "Special offer for {name}! Upgrade your plan to {newPlan} and get {discount}% off for the first 3 months. Call us at (555) 123-4567 to upgrade now!",
    lastUsed: "2023-05-05",
    usageCount: 850,
  },
  {
    id: 5,
    name: "Password Reset",
    description: "Template for password reset notifications",
    content:
      "Your password reset code is: {code}. This code will expire in 10 minutes. If you didn't request this, please contact support immediately.",
    lastUsed: "2023-04-20",
    usageCount: 125,
  },
  {
    id: 6,
    name: "Service Renewal",
    description: "Template for service renewal reminders",
    content:
      "Dear {name}, your service plan will expire on {expiryDate}. Renew now to avoid interruption. Call us at (555) 123-4567 for assistance.",
    lastUsed: "2023-04-15",
    usageCount: 780,
  },
]
