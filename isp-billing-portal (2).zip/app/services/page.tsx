import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Plus, Search, Filter, MoreHorizontal, Download, Edit, Trash2, Eye, Wifi, Signal, Zap } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function ServicesPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Services & Equipment</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline">
              <Wifi className="mr-2 h-4 w-4" />
              Network Status
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Service
            </Button>
          </div>
        </div>

        <Tabs defaultValue="services" className="space-y-4">
          <TabsList>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="equipment">Equipment</TabsTrigger>
            <TabsTrigger value="network">Network Status</TabsTrigger>
          </TabsList>

          <TabsContent value="services" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Services</CardTitle>
                  <Signal className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">2,843</div>
                  <p className="text-xs text-muted-foreground">+201 from last month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Residential Services</CardTitle>
                  <Wifi className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">2,350</div>
                  <p className="text-xs text-muted-foreground">+180 from last month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Business Services</CardTitle>
                  <Zap className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">493</div>
                  <p className="text-xs text-muted-foreground">+21 from last month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Network Utilization</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">78%</div>
                  <Progress value={78} className="mt-2" />
                </CardContent>
              </Card>
            </div>

            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search services..." className="w-full min-w-[260px] pl-8" />
                </div>
                <Button variant="outline" size="sm" className="h-9">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>

            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Service ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Installation Date</TableHead>
                    <TableHead>Monthly Fee</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {services.map((service) => (
                    <TableRow key={service.id}>
                      <TableCell className="font-medium">{service.id}</TableCell>
                      <TableCell>{service.customer}</TableCell>
                      <TableCell>{service.plan}</TableCell>
                      <TableCell>{service.installDate}</TableCell>
                      <TableCell>${service.monthlyFee}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            service.status === "Active"
                              ? "outline"
                              : service.status === "Suspended"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {service.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit service
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Trash2 className="mr-2 h-4 w-4" />
                              Cancel service
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious href="#" />
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">1</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#" isActive>
                    2
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">3</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
                <PaginationItem>
                  <PaginationNext href="#" />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </TabsContent>

          <TabsContent value="equipment" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium">Equipment Inventory</h2>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Equipment
              </Button>
            </div>

            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Equipment ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Model</TableHead>
                    <TableHead>Serial Number</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {equipment.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.id}</TableCell>
                      <TableCell>{item.type}</TableCell>
                      <TableCell>{item.model}</TableCell>
                      <TableCell>{item.serialNumber}</TableCell>
                      <TableCell>{item.assignedTo}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            item.status === "Deployed"
                              ? "outline"
                              : item.status === "Defective"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {item.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Eye className="mr-2 h-4 w-4" />
                          Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="network" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>Network Status</CardTitle>
                  <CardDescription>Current network performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium">Core Network</div>
                        <Badge variant="outline" className="bg-green-50">
                          Operational
                        </Badge>
                      </div>
                      <Progress value={98} className="h-2" />
                      <p className="text-xs text-muted-foreground mt-1">98% uptime in the last 30 days</p>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium">Distribution Network</div>
                        <Badge variant="outline" className="bg-green-50">
                          Operational
                        </Badge>
                      </div>
                      <Progress value={96} className="h-2" />
                      <p className="text-xs text-muted-foreground mt-1">96% uptime in the last 30 days</p>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium">Access Network</div>
                        <Badge variant="outline" className="bg-yellow-50">
                          Partial Issues
                        </Badge>
                      </div>
                      <Progress value={92} className="h-2" />
                      <p className="text-xs text-muted-foreground mt-1">92% uptime in the last 30 days</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Bandwidth Utilization</CardTitle>
                  <CardDescription>Current network load</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium">Downtown Area</div>
                        <div className="text-sm">78%</div>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium">Residential District</div>
                        <div className="text-sm">65%</div>
                      </div>
                      <Progress value={65} className="h-2" />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium">Business Park</div>
                        <div className="text-sm">82%</div>
                      </div>
                      <Progress value={82} className="h-2" />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium">Industrial Zone</div>
                        <div className="text-sm">45%</div>
                      </div>
                      <Progress value={45} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Active Alerts</CardTitle>
                  <CardDescription>Current network issues</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {networkAlerts.map((alert, index) => (
                      <div key={index} className="flex items-start space-x-3 pb-3 border-b">
                        <div
                          className={`w-2 h-2 mt-2 rounded-full ${
                            alert.severity === "High"
                              ? "bg-red-500"
                              : alert.severity === "Medium"
                                ? "bg-yellow-500"
                                : "bg-blue-500"
                          }`}
                        />
                        <div>
                          <p className="text-sm font-medium">{alert.title}</p>
                          <p className="text-xs text-muted-foreground">{alert.location}</p>
                          <p className="text-xs text-muted-foreground">{alert.time}</p>
                        </div>
                      </div>
                    ))}

                    {networkAlerts.length === 0 && (
                      <div className="text-center py-6">
                        <p className="text-muted-foreground">No active alerts</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

const services = [
  {
    id: "SRV001",
    customer: "John Smith",
    plan: "Fiber 1Gbps",
    installDate: "2023-01-15",
    monthlyFee: "129.99",
    status: "Active",
  },
  {
    id: "SRV002",
    customer: "Emily Johnson",
    plan: "Cable 500Mbps",
    installDate: "2023-02-20",
    monthlyFee: "89.99",
    status: "Active",
  },
  {
    id: "SRV003",
    customer: "Michael Williams",
    plan: "DSL 100Mbps",
    installDate: "2023-01-10",
    monthlyFee: "59.99",
    status: "Suspended",
  },
  {
    id: "SRV004",
    customer: "Jessica Brown",
    plan: "Fiber 500Mbps",
    installDate: "2023-03-05",
    monthlyFee: "99.99",
    status: "Active",
  },
  {
    id: "SRV005",
    customer: "David Miller",
    plan: "Business Fiber 2Gbps",
    installDate: "2023-02-01",
    monthlyFee: "199.99",
    status: "Active",
  },
  {
    id: "SRV006",
    customer: "Sarah Davis",
    plan: "Cable 250Mbps",
    installDate: "2023-03-15",
    monthlyFee: "79.99",
    status: "Pending",
  },
  {
    id: "SRV007",
    customer: "Robert Wilson",
    plan: "Fiber 1Gbps",
    installDate: "2023-01-25",
    monthlyFee: "129.99",
    status: "Active",
  },
  {
    id: "SRV008",
    customer: "Jennifer Taylor",
    plan: "DSL 50Mbps",
    installDate: "2023-02-10",
    monthlyFee: "49.99",
    status: "Inactive",
  },
  {
    id: "SRV009",
    customer: "Thomas Anderson",
    plan: "Business Fiber 1Gbps",
    installDate: "2023-03-01",
    monthlyFee: "149.99",
    status: "Active",
  },
  {
    id: "SRV010",
    customer: "Lisa Martinez",
    plan: "Cable 100Mbps",
    installDate: "2023-02-15",
    monthlyFee: "69.99",
    status: "Active",
  },
]

const equipment = [
  {
    id: "EQP001",
    type: "Router",
    model: "Cisco 2900",
    serialNumber: "CSC29001234",
    assignedTo: "John Smith",
    status: "Deployed",
  },
  {
    id: "EQP002",
    type: "Modem",
    model: "Arris SB8200",
    serialNumber: "ARR82001234",
    assignedTo: "Emily Johnson",
    status: "Deployed",
  },
  {
    id: "EQP003",
    type: "Router",
    model: "Netgear R7000",
    serialNumber: "NTG70001234",
    assignedTo: "Michael Williams",
    status: "Defective",
  },
  {
    id: "EQP004",
    type: "Access Point",
    model: "Ubiquiti UAP-AC-PRO",
    serialNumber: "UBQ12341234",
    assignedTo: "Jessica Brown",
    status: "Deployed",
  },
  {
    id: "EQP005",
    type: "Switch",
    model: "Cisco Catalyst 2960",
    serialNumber: "CSC29601234",
    assignedTo: "David Miller",
    status: "Deployed",
  },
  {
    id: "EQP006",
    type: "Modem",
    model: "Motorola MB8600",
    serialNumber: "MTR86001234",
    assignedTo: "Sarah Davis",
    status: "In Stock",
  },
  {
    id: "EQP007",
    type: "Router",
    model: "Asus RT-AX88U",
    serialNumber: "ASU88U1234",
    assignedTo: "Robert Wilson",
    status: "Deployed",
  },
  {
    id: "EQP008",
    type: "Modem",
    model: "Arris SB6190",
    serialNumber: "ARR61901234",
    assignedTo: "Jennifer Taylor",
    status: "Deployed",
  },
  {
    id: "EQP009",
    type: "Switch",
    model: "Netgear GS308",
    serialNumber: "NTG3081234",
    assignedTo: "Thomas Anderson",
    status: "Deployed",
  },
  {
    id: "EQP010",
    type: "Access Point",
    model: "TP-Link EAP245",
    serialNumber: "TPL2451234",
    assignedTo: "Lisa Martinez",
    status: "Deployed",
  },
]

const networkAlerts = [
  {
    title: "Fiber Cut Detected",
    location: "Downtown Area - Main Street",
    time: "Today, 10:23 AM",
    severity: "High",
  },
  {
    title: "High Bandwidth Usage",
    location: "Business Park - Tower 3",
    time: "Today, 09:45 AM",
    severity: "Medium",
  },
  {
    title: "Router Offline",
    location: "Residential District - Oak Avenue",
    time: "Yesterday, 11:30 PM",
    severity: "Medium",
  },
  {
    title: "Scheduled Maintenance",
    location: "Industrial Zone - Sector B",
    time: "Tomorrow, 02:00 AM",
    severity: "Low",
  },
]
