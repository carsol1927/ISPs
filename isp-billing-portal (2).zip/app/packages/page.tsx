import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Plus, Search, Filter, Edit, Trash2, Download } from "lucide-react"

export default function PackagesPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Service Packages</h1>
          <div className="flex items-center gap-2">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Package
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Packages</TabsTrigger>
            <TabsTrigger value="hotspot">Hotspot</TabsTrigger>
            <TabsTrigger value="pppoe">PPPoE</TabsTrigger>
            <TabsTrigger value="dataplan">Data Plans</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search packages..." className="w-full min-w-[260px] pl-8" />
                </div>
                <Button variant="outline" size="sm" className="h-9">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {packages.map((pkg) => (
                <Card key={pkg.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{pkg.name}</CardTitle>
                        <CardDescription>{pkg.description}</CardDescription>
                      </div>
                      <Badge
                        className={
                          pkg.type === "Hotspot"
                            ? "bg-blue-100"
                            : pkg.type === "PPPoE"
                              ? "bg-green-100"
                              : "bg-purple-100"
                        }
                      >
                        {pkg.type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold mb-2">
                      ${pkg.price}
                      <span className="text-sm font-normal text-muted-foreground">/month</span>
                    </div>
                    <ul className="space-y-2 mb-4">
                      {pkg.features.map((feature, i) => (
                        <li key={i} className="flex items-center text-sm">
                          <span className="mr-2 text-green-500">✓</span> {feature}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter className="flex justify-between bg-muted/50 pt-2">
                    <div className="text-sm text-muted-foreground">{pkg.users} users</div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm" className="text-red-500">
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="hotspot" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {packages
                .filter((pkg) => pkg.type === "Hotspot")
                .map((pkg) => (
                  <Card key={pkg.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{pkg.name}</CardTitle>
                          <CardDescription>{pkg.description}</CardDescription>
                        </div>
                        <Badge className="bg-blue-100">Hotspot</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold mb-2">
                        ${pkg.price}
                        <span className="text-sm font-normal text-muted-foreground">/month</span>
                      </div>
                      <ul className="space-y-2 mb-4">
                        {pkg.features.map((feature, i) => (
                          <li key={i} className="flex items-center text-sm">
                            <span className="mr-2 text-green-500">✓</span> {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter className="flex justify-between bg-muted/50 pt-2">
                      <div className="text-sm text-muted-foreground">{pkg.users} users</div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-500">
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="pppoe" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {packages
                .filter((pkg) => pkg.type === "PPPoE")
                .map((pkg) => (
                  <Card key={pkg.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{pkg.name}</CardTitle>
                          <CardDescription>{pkg.description}</CardDescription>
                        </div>
                        <Badge className="bg-green-100">PPPoE</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold mb-2">
                        ${pkg.price}
                        <span className="text-sm font-normal text-muted-foreground">/month</span>
                      </div>
                      <ul className="space-y-2 mb-4">
                        {pkg.features.map((feature, i) => (
                          <li key={i} className="flex items-center text-sm">
                            <span className="mr-2 text-green-500">✓</span> {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter className="flex justify-between bg-muted/50 pt-2">
                      <div className="text-sm text-muted-foreground">{pkg.users} users</div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-500">
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="dataplan" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {packages
                .filter((pkg) => pkg.type === "Data Plan")
                .map((pkg) => (
                  <Card key={pkg.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{pkg.name}</CardTitle>
                          <CardDescription>{pkg.description}</CardDescription>
                        </div>
                        <Badge className="bg-purple-100">Data Plan</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold mb-2">
                        ${pkg.price}
                        <span className="text-sm font-normal text-muted-foreground">/month</span>
                      </div>
                      <ul className="space-y-2 mb-4">
                        {pkg.features.map((feature, i) => (
                          <li key={i} className="flex items-center text-sm">
                            <span className="mr-2 text-green-500">✓</span> {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter className="flex justify-between bg-muted/50 pt-2">
                      <div className="text-sm text-muted-foreground">{pkg.users} users</div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-500">
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

const packages = [
  {
    id: 1,
    name: "Hotspot Basic",
    description: "Basic hotspot access for casual users",
    type: "Hotspot",
    price: "9.99",
    features: [
      "5 Mbps download speed",
      "2 Mbps upload speed",
      "5 GB data limit",
      "24-hour access",
      "Single device connection",
    ],
    users: 245,
  },
  {
    id: 2,
    name: "Hotspot Premium",
    description: "Premium hotspot access for regular users",
    type: "Hotspot",
    price: "19.99",
    features: [
      "15 Mbps download speed",
      "5 Mbps upload speed",
      "20 GB data limit",
      "7-day access",
      "Multiple device connection",
      "Priority bandwidth",
    ],
    users: 350,
  },
  {
    id: 3,
    name: "Hotspot Unlimited",
    description: "Unlimited hotspot access for power users",
    type: "Hotspot",
    price: "29.99",
    features: [
      "25 Mbps download speed",
      "10 Mbps upload speed",
      "Unlimited data",
      "30-day access",
      "Multiple device connection",
      "Priority bandwidth",
      "24/7 support",
    ],
    users: 250,
  },
  {
    id: 4,
    name: "PPPoE Home",
    description: "Reliable internet for home users",
    type: "PPPoE",
    price: "39.99",
    features: [
      "50 Mbps download speed",
      "15 Mbps upload speed",
      "Unlimited data",
      "Static IP available",
      "Multiple device connection",
      "Basic technical support",
    ],
    users: 320,
  },
  {
    id: 5,
    name: "PPPoE Business",
    description: "High-performance internet for businesses",
    type: "PPPoE",
    price: "79.99",
    features: [
      "100 Mbps download speed",
      "50 Mbps upload speed",
      "Unlimited data",
      "Static IP included",
      "Multiple device connection",
      "Priority technical support",
      "99.9% uptime guarantee",
    ],
    users: 180,
  },
  {
    id: 6,
    name: "PPPoE Enterprise",
    description: "Enterprise-grade connectivity solution",
    type: "PPPoE",
    price: "149.99",
    features: [
      "500 Mbps download speed",
      "250 Mbps upload speed",
      "Unlimited data",
      "Multiple static IPs",
      "Dedicated account manager",
      "24/7 premium support",
      "99.99% uptime guarantee",
      "Network monitoring",
    ],
    users: 120,
  },
  {
    id: 7,
    name: "Data Basic",
    description: "Basic data plan for light users",
    type: "Data Plan",
    price: "14.99",
    features: ["10 GB data limit", "30-day validity", "10 Mbps speed cap", "Data rollover", "Basic support"],
    users: 175,
  },
  {
    id: 8,
    name: "Data Standard",
    description: "Standard data plan for regular users",
    type: "Data Plan",
    price: "24.99",
    features: [
      "30 GB data limit",
      "30-day validity",
      "25 Mbps speed cap",
      "Data rollover",
      "Priority support",
      "Off-peak unlimited usage",
    ],
    users: 210,
  },
  {
    id: 9,
    name: "Data Unlimited",
    description: "Unlimited data plan for heavy users",
    type: "Data Plan",
    price: "49.99",
    features: [
      "Unlimited data",
      "30-day validity",
      "50 Mbps speed cap",
      "Priority network access",
      "24/7 premium support",
      "Multi-device sharing",
    ],
    users: 140,
  },
]
