import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CreditCard,
  DollarSign,
  Download,
  Users,
  ArrowUpRight,
  TrendingUp,
  BarChart2,
  PieChart,
  Activity,
  AlertCircle,
  UserMinus,
  UserPlus,
  Percent,
  Zap,
  LineChart,
  MessageSquare,
  Wifi,
  Globe,
} from "lucide-react"
import { RevenueChart } from "@/components/revenue-chart"
import { RecentInvoices } from "@/components/recent-invoices"
import { CustomerStats } from "@/components/customer-stats"
import { ActiveUserStats } from "@/components/active-user-stats"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"

// Add this after the imports
function TimeRangeSelector({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center", className)}>
      <Select defaultValue="week">
        <SelectTrigger className="h-8 w-[110px]">
          <SelectValue placeholder="Time Range" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="week">Week</SelectItem>
          <SelectItem value="month">Month</SelectItem>
          <SelectItem value="quarter">Quarter</SelectItem>
          <SelectItem value="year">Year</SelectItem>
          <SelectItem value="all">All Time</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}

export default function DashboardPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">ISP Billing Dashboard</h1>
        <div className="flex items-center gap-2">
          <Select defaultValue="monthly">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <CreditCard className="mr-2 h-4 w-4" />
            Process Payments
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$45,231.89</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" /> +20.1%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ARPU</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$89.75</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" /> +5.2%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Collections Rate</CardTitle>
            <Percent className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">96.8%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" /> +1.2%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Churn Rate</CardTitle>
            <UserMinus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2.4%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" /> -0.3%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Network Uptime</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">99.95%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" /> +0.02%
              </span>{" "}
              from last week
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">SMS Balance</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8,500</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-red-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" /> -1,500
              </span>{" "}
              from last week
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="financial" className="space-y-4">
        <TabsList className="grid grid-cols-5 md:w-[600px]">
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="network">Network</TabsTrigger>
          <TabsTrigger value="active-users">Active Users</TabsTrigger>
          <TabsTrigger value="predictive">Predictive</TabsTrigger>
        </TabsList>

        <TabsContent value="financial" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="col-span-2">
              <CardHeader className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Revenue Trends</CardTitle>
                    <CardDescription>Revenue breakdown by service category</CardDescription>
                  </div>
                  <TimeRangeSelector />
                </div>
              </CardHeader>
              <CardContent className="pl-2">
                <RevenueChart />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue Forecast</CardTitle>
                <CardDescription>3-month projection based on historical data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Next Month</p>
                      <p className="text-xs text-muted-foreground">Projected</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">$47,500</p>
                      <p className="text-xs text-green-500">+5.0%</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">2 Months</p>
                      <p className="text-xs text-muted-foreground">Projected</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">$49,800</p>
                      <p className="text-xs text-green-500">+4.8%</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">3 Months</p>
                      <p className="text-xs text-muted-foreground">Projected</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">$52,100</p>
                      <p className="text-xs text-green-500">+4.6%</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <LineChart className="mr-2 h-4 w-4" />
                      View Detailed Forecast
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Payment Method Distribution</CardTitle>
                <CardDescription>Breakdown by payment type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center">
                  <PieChart className="h-16 w-16 text-muted-foreground" />
                </div>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 rounded-full bg-blue-500 mr-2"></div>
                      <p className="text-sm">Credit Card</p>
                    </div>
                    <p className="text-sm font-medium">68%</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
                      <p className="text-sm">ACH/Bank Transfer</p>
                    </div>
                    <p className="text-sm font-medium">22%</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 rounded-full bg-yellow-500 mr-2"></div>
                      <p className="text-sm">Other Methods</p>
                    </div>
                    <p className="text-sm font-medium">10%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Aging Accounts Receivable</CardTitle>
                <CardDescription>Outstanding payments by age</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Current</p>
                      <p className="text-sm font-medium">$32,450</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 w-[65%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">1-30 days</p>
                      <p className="text-sm font-medium">$12,340</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[25%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">31-60 days</p>
                      <p className="text-sm font-medium">$3,450</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-orange-500 w-[7%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">61+ days</p>
                      <p className="text-sm font-medium">$1,560</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-red-500 w-[3%]"></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Invoices</CardTitle>
                <CardDescription>Latest processed invoices</CardDescription>
              </CardHeader>
              <CardContent>
                <RecentInvoices />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="customers" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="col-span-2">
              <CardHeader className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Customer Growth</CardTitle>
                    <CardDescription>Net customer growth</CardDescription>
                  </div>
                  <TimeRangeSelector />
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <CustomerStats />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Customer Acquisition</CardTitle>
                <CardDescription>New customers per month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">This Month</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">180</p>
                      <p className="text-xs text-green-500">+12.5% from last month</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Cost Per Acquisition</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">$42.50</p>
                      <p className="text-xs text-green-500">-3.2% from last month</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Conversion Rate</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">8.4%</p>
                      <p className="text-xs text-green-500">+0.6% from last month</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <UserPlus className="mr-2 h-4 w-4" />
                      View Acquisition Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Service Plan Distribution</CardTitle>
                    <CardDescription>Breakdown by plan type</CardDescription>
                  </div>
                  <TimeRangeSelector />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Fiber 1Gbps</p>
                      <p className="text-sm font-medium">1,200 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 w-[42%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Fiber 500Mbps</p>
                      <p className="text-sm font-medium">800 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-blue-400 w-[28%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Cable 500Mbps</p>
                      <p className="text-sm font-medium">500 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 w-[18%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Cable 250Mbps</p>
                      <p className="text-sm font-medium">300 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-400 w-[10%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">DSL</p>
                      <p className="text-sm font-medium">50 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[2%]"></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Customer Lifetime</CardTitle>
                <CardDescription>Average customer retention</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Average Lifetime</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">3.2 years</p>
                      <p className="text-xs text-green-500">+0.2 years from last year</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Lifetime Value</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">$3,450</p>
                      <p className="text-xs text-green-500">+$210 from last year</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Retention Rate</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">97.6%</p>
                      <p className="text-xs text-green-500">+0.3% from last month</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <BarChart2 className="mr-2 h-4 w-4" />
                      View Retention Analysis
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Customer Segments</CardTitle>
                <CardDescription>Distribution by customer type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center">
                  <PieChart className="h-16 w-16 text-muted-foreground" />
                </div>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 rounded-full bg-blue-500 mr-2"></div>
                      <p className="text-sm">Residential</p>
                    </div>
                    <p className="text-sm font-medium">1,500 (64%)</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
                      <p className="text-sm">Small Business</p>
                    </div>
                    <p className="text-sm font-medium">500 (21%)</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 rounded-full bg-purple-500 mr-2"></div>
                      <p className="text-sm">Enterprise</p>
                    </div>
                    <p className="text-sm font-medium">350 (15%)</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="network" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="col-span-2">
              <CardHeader className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Bandwidth Consumption</CardTitle>
                    <CardDescription>Total data usage over time</CardDescription>
                  </div>
                  <TimeRangeSelector />
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ActiveUserStats />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Bandwidth Utilization</CardTitle>
                    <CardDescription>Percentage of available bandwidth used</CardDescription>
                  </div>
                  <TimeRangeSelector />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Downtown Area</p>
                      <p className="text-sm font-medium">78%</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[78%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Residential District</p>
                      <p className="text-sm font-medium">65%</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 w-[65%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Business Park</p>
                      <p className="text-sm font-medium">82%</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-orange-500 w-[82%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Industrial Zone</p>
                      <p className="text-sm font-medium">45%</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 w-[45%]"></div>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <Activity className="mr-2 h-4 w-4" />
                      View Network Map
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Top Users</CardTitle>
                <CardDescription>Highest bandwidth consumers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                        <Users className="h-4 w-4 text-blue-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Business Park Tower 3</p>
                        <p className="text-xs text-muted-foreground">Enterprise Client</p>
                      </div>
                    </div>
                    <p className="text-sm font-medium">450 GB</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                        <Users className="h-4 w-4 text-green-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Oak Avenue Apartments</p>
                        <p className="text-xs text-muted-foreground">Residential Complex</p>
                      </div>
                    </div>
                    <p className="text-sm font-medium">320 GB</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center mr-2">
                        <Users className="h-4 w-4 text-purple-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Main Street Mall</p>
                        <p className="text-xs text-muted-foreground">Business Client</p>
                      </div>
                    </div>
                    <p className="text-sm font-medium">280 GB</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center mr-2">
                        <Users className="h-4 w-4 text-orange-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Riverside Condos</p>
                        <p className="text-xs text-muted-foreground">Residential Complex</p>
                      </div>
                    </div>
                    <p className="text-sm font-medium">210 GB</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Service Quality</CardTitle>
                <CardDescription>Network performance metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Core Network</p>
                      <p className="text-sm font-medium">98% uptime</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 w-[98%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Distribution Network</p>
                      <p className="text-sm font-medium">96% uptime</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 w-[96%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Access Network</p>
                      <p className="text-sm font-medium">92% uptime</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[92%]"></div>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <AlertCircle className="mr-2 h-4 w-4" />
                      View Network Alerts
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Speed Test Results</CardTitle>
                <CardDescription>Actual vs. advertised speeds</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Fiber 1Gbps</p>
                      <p className="text-xs text-muted-foreground">Average download</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">940 Mbps</p>
                      <p className="text-xs text-green-500">94% of advertised</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Cable 500Mbps</p>
                      <p className="text-xs text-muted-foreground">Average download</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">450 Mbps</p>
                      <p className="text-xs text-green-500">90% of advertised</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">DSL 100Mbps</p>
                      <p className="text-xs text-muted-foreground">Average download</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">85 Mbps</p>
                      <p className="text-xs text-yellow-500">85% of advertised</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <Activity className="mr-2 h-4 w-4" />
                      View Detailed Results
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="active-users" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>PPPoE Users</CardTitle>
                    <CardDescription>Average active connections over time</CardDescription>
                  </div>
                  <TimeRangeSelector />
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center">
                  <Globe className="h-16 w-16 text-muted-foreground" />
                </div>
                <div className="space-y-4 mt-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Current Active</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">1,842 users</p>
                      <p className="text-xs text-green-500">+3.2% from last week</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Peak Today</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">2,156 users</p>
                      <p className="text-xs text-muted-foreground">at 8:30 PM</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Average Session</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">4.2 hours</p>
                      <p className="text-xs text-green-500">+0.3 hours from last week</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Hotspot Users</CardTitle>
                    <CardDescription>Average active connections over time</CardDescription>
                  </div>
                  <TimeRangeSelector />
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center">
                  <Wifi className="h-16 w-16 text-muted-foreground" />
                </div>
                <div className="space-y-4 mt-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Current Active</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">756 users</p>
                      <p className="text-xs text-green-500">+5.8% from last week</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Peak Today</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">912 users</p>
                      <p className="text-xs text-muted-foreground">at 12:15 PM</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Average Session</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">1.8 hours</p>
                      <p className="text-xs text-green-500">+0.2 hours from last week</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Connection Types</CardTitle>
                <CardDescription>Distribution by connection method</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center">
                  <PieChart className="h-16 w-16 text-muted-foreground" />
                </div>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 rounded-full bg-blue-500 mr-2"></div>
                      <p className="text-sm">PPPoE</p>
                    </div>
                    <p className="text-sm font-medium">1,842 (71%)</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
                      <p className="text-sm">Hotspot</p>
                    </div>
                    <p className="text-sm font-medium">756 (29%)</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Peak Usage Times</CardTitle>
                <CardDescription>When users are most active</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Morning (6AM-12PM)</p>
                      <p className="text-sm font-medium">1,450 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[55%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Afternoon (12PM-6PM)</p>
                      <p className="text-sm font-medium">1,850 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-orange-500 w-[70%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Evening (6PM-12AM)</p>
                      <p className="text-sm font-medium">2,650 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-red-500 w-[100%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Night (12AM-6AM)</p>
                      <p className="text-sm font-medium">950 users</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 w-[35%]"></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Device Distribution</CardTitle>
                <CardDescription>Types of devices connecting</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Smartphones</p>
                      <p className="text-sm font-medium">1,250 devices</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 w-[48%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Laptops/Desktops</p>
                      <p className="text-sm font-medium">980 devices</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 w-[38%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Tablets</p>
                      <p className="text-sm font-medium">210 devices</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[8%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">IoT/Other</p>
                      <p className="text-sm font-medium">158 devices</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-purple-500 w-[6%]"></div>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <Activity className="mr-2 h-4 w-4" />
                      View Detailed Analytics
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="predictive" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Churn Prediction</CardTitle>
                <CardDescription>Customers at risk of cancellation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="text-sm font-medium">High Risk ({">"}70%)</p>
                      <p className="text-xs text-muted-foreground">Likely to cancel within 30 days</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">42 customers</p>
                      <p className="text-xs text-red-500">$4,580 monthly revenue</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="text-sm font-medium">Medium Risk (30-70%)</p>
                      <p className="text-xs text-muted-foreground">May cancel within 90 days</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">85 customers</p>
                      <p className="text-xs text-orange-500">$8,750 monthly revenue</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="text-sm font-medium">Low Risk ({"<"}30%)</p>
                      <p className="text-xs text-muted-foreground">Unlikely to cancel</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">2,223 customers</p>
                      <p className="text-xs text-green-500">$198,450 monthly revenue</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <UserMinus className="mr-2 h-4 w-4" />
                      View At-Risk Customers
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Top Churn Risk Factors</CardTitle>
                    <CardDescription>Primary reasons for customer churn</CardDescription>
                  </div>
                  <TimeRangeSelector />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Service Outages</p>
                      <p className="text-sm font-medium">35%</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-red-500 w-[35%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Price Sensitivity</p>
                      <p className="text-sm font-medium">28%</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-orange-500 w-[28%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Competitor Offers</p>
                      <p className="text-sm font-medium">22%</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[22%]"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm">Customer Service</p>
                      <p className="text-sm font-medium">15%</p>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 w-[15%]"></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>Upsell/Cross-sell Opportunities</CardTitle>
                <CardDescription>Customers with upgrade potential</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                        <Users className="h-4 w-4 text-blue-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Cable 250Mbps Users</p>
                        <p className="text-xs text-muted-foreground">High usage patterns</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">120 customers</p>
                      <p className="text-xs text-green-500">Upgrade to 500Mbps</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                        <Users className="h-4 w-4 text-green-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Internet-Only Customers</p>
                        <p className="text-xs text-muted-foreground">Streaming service users</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">85 customers</p>
                      <p className="text-xs text-green-500">Add TV bundle</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center mr-2">
                        <Users className="h-4 w-4 text-purple-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Small Business Customers</p>
                        <p className="text-xs text-muted-foreground">Growing usage trends</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">42 customers</p>
                      <p className="text-xs text-green-500">Upgrade to Business Pro</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center mr-2">
                        <Users className="h-4 w-4 text-orange-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Long-term Customers</p>
                        <p className="text-xs text-muted-foreground">2+ years, outdated equipment</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">68 customers</p>
                      <p className="text-xs text-green-500">Equipment upgrade</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <TrendingUp className="mr-2 h-4 w-4" />
                      View All Opportunities
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue Growth Potential</CardTitle>
                <CardDescription>Projected additional revenue</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Upsell Potential</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">$12,450/month</p>
                      <p className="text-xs text-green-500">315 customers</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Cross-sell Potential</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">$8,750/month</p>
                      <p className="text-xs text-green-500">210 customers</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">Retention Savings</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">$4,580/month</p>
                      <p className="text-xs text-green-500">42 at-risk customers</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="w-full">
                      <BarChart2 className="mr-2 h-4 w-4" />
                      View Revenue Forecast
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
