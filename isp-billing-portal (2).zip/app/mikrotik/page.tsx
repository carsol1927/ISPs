"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Router,
  Wifi,
  Activity,
  HardDrive,
  RefreshCw,
  Settings,
  AlertCircleIcon,
  Users,
  Globe,
  Cpu,
  BarChart3,
  Clock,
  Download,
  Upload,
  Shield,
  Terminal,
  Link,
  Unlink,
  Save,
  Trash2,
  FileText,
  Zap,
  Layers,
  Server,
  Network,
  Lock,
  Key,
  UserPlus,
  Gauge,
  ArrowUpDown,
  Repeat,
  Webhook,
  FileCode,
  Wrench,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useState } from "react"

export default function MikrotikPage() {
  const [isConnected, setIsConnected] = useState(false)
  const [activeRouter, setActiveRouter] = useState<string | null>(null)
  const [showConnectionForm, setShowConnectionForm] = useState(false)

  const handleConnect = () => {
    // Simulate API connection
    setIsConnected(true)
    setShowConnectionForm(false)
    setActiveRouter("Core Router")
  }

  const handleDisconnect = () => {
    setIsConnected(false)
    setActiveRouter(null)
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-semibold">Mikrotik Management</h1>
            {isConnected && activeRouter && (
              <Badge variant="outline" className="bg-green-50">
                Connected to {activeRouter}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            {isConnected ? (
              <>
                <Button variant="outline" onClick={() => setShowConnectionForm(true)}>
                  <Link className="mr-2 h-4 w-4" />
                  Change Router
                </Button>
                <Button variant="outline" onClick={handleDisconnect}>
                  <Unlink className="mr-2 h-4 w-4" />
                  Disconnect
                </Button>
                <Button variant="outline">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Refresh Status
                </Button>
                <Button>
                  <Terminal className="mr-2 h-4 w-4" />
                  Terminal
                </Button>
              </>
            ) : (
              <Button onClick={() => setShowConnectionForm(true)}>
                <Link className="mr-2 h-4 w-4" />
                Connect to Router
              </Button>
            )}
          </div>
        </div>

        {!isConnected && !showConnectionForm && (
          <Card>
            <CardHeader>
              <CardTitle>Connect to Mikrotik Router</CardTitle>
              <CardDescription>
                Connect to your Mikrotik router using the API to manage and monitor your network.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center p-6">
              <Router className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-xl font-medium mb-2">No Active Connection</h3>
              <p className="text-muted-foreground text-center mb-6">
                Connect to your Mikrotik router to view and manage your network infrastructure.
              </p>
              <Button onClick={() => setShowConnectionForm(true)}>
                <Link className="mr-2 h-4 w-4" />
                Connect to Router
              </Button>
            </CardContent>
          </Card>
        )}

        {showConnectionForm && (
          <Card>
            <CardHeader>
              <CardTitle>Connect to Mikrotik Router</CardTitle>
              <CardDescription>Enter your Mikrotik router credentials to establish a connection.</CardDescription>
            </CardHeader>
            <CardContent>
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault()
                  handleConnect()
                }}
              >
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="ip">IP Address</Label>
                    <Input id="ip" placeholder="192.168.1.1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="port">Port</Label>
                    <Input id="port" placeholder="8728" defaultValue="8728" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input id="username" placeholder="admin" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="secure" />
                    <label
                      htmlFor="secure"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Use secure connection (API-SSL)
                    </label>
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowConnectionForm(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Connect</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {isConnected && (
          <>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">CPU Load</CardTitle>
                  <Cpu className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">35%</div>
                  <div className="mt-2 space-y-1">
                    <div className="flex text-xs text-muted-foreground justify-between">
                      <span>Current</span>
                      <span>35%</span>
                    </div>
                    <Progress value={35} className="h-2" />
                    <div className="flex text-xs text-muted-foreground justify-between">
                      <span>5 min average</span>
                      <span>32%</span>
                    </div>
                    <Progress value={32} className="h-2" />
                    <div className="flex text-xs text-muted-foreground justify-between">
                      <span>1 hour average</span>
                      <span>28%</span>
                    </div>
                    <Progress value={28} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
                  <HardDrive className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">42%</div>
                  <div className="mt-2 space-y-1">
                    <div className="flex text-xs text-muted-foreground justify-between">
                      <span>Used</span>
                      <span>512 MB / 1.2 GB</span>
                    </div>
                    <Progress value={42} className="h-2" />
                    <div className="flex text-xs text-muted-foreground justify-between mt-2">
                      <span>Free</span>
                      <span>688 MB</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Connections</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1,892</div>
                  <div className="mt-2 space-y-1">
                    <div className="flex text-xs text-muted-foreground justify-between">
                      <span>PPPoE</span>
                      <span>1,245</span>
                    </div>
                    <Progress value={65} className="h-2" />
                    <div className="flex text-xs text-muted-foreground justify-between">
                      <span>Hotspot</span>
                      <span>647</span>
                    </div>
                    <Progress value={35} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Uptime</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">45d 12h 36m</div>
                  <div className="mt-2 space-y-1">
                    <div className="flex text-xs text-muted-foreground justify-between">
                      <span>Version</span>
                      <span>RouterOS 6.48.6</span>
                    </div>
                    <div className="flex text-xs text-muted-foreground justify-between">
                      <span>Last Reboot</span>
                      <span>Mar 12, 2023</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card className="lg:col-span-2">
                <CardHeader className="flex flex-row items-center justify-between space-y-0">
                  <div>
                    <CardTitle>Traffic Overview</CardTitle>
                    <CardDescription>Network traffic for the last 24 hours</CardDescription>
                  </div>
                  <Select defaultValue="ether1">
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select interface" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ether1">ether1 (WAN)</SelectItem>
                      <SelectItem value="ether2">ether2 (LAN)</SelectItem>
                      <SelectItem value="sfp1">sfp1 (Fiber)</SelectItem>
                      <SelectItem value="all">All Interfaces</SelectItem>
                    </SelectContent>
                  </Select>
                </CardHeader>
                <CardContent className="pl-2">
                  <div className="h-[200px] w-full bg-muted/20 rounded-md flex items-center justify-center">
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <BarChart3 className="h-8 w-8" />
                      <span>Traffic Graph Visualization</span>
                      <div className="flex gap-4 text-xs">
                        <div className="flex items-center">
                          <div className="h-2 w-2 rounded-full bg-blue-500 mr-1"></div>
                          <span>Download (45 Mbps avg)</span>
                        </div>
                        <div className="flex items-center">
                          <div className="h-2 w-2 rounded-full bg-green-500 mr-1"></div>
                          <span>Upload (15 Mbps avg)</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Bandwidth Usage</CardTitle>
                  <CardDescription>Current bandwidth consumption</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <Download className="mr-2 h-4 w-4 text-blue-500" />
                          <span>Download</span>
                        </div>
                        <span className="font-medium">45.2 Mbps</span>
                      </div>
                      <Progress value={45} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <Upload className="mr-2 h-4 w-4 text-green-500" />
                          <span>Upload</span>
                        </div>
                        <span className="font-medium">15.8 Mbps</span>
                      </div>
                      <Progress value={16} className="h-2" />
                    </div>
                    <div className="pt-2">
                      <div className="rounded-md bg-muted p-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Daily Transfer</span>
                          <span>1.2 TB / 2.5 TB</span>
                        </div>
                        <Progress value={48} className="h-2 mt-2" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Tabs defaultValue="routers" className="space-y-4">
              <TabsList className="grid grid-cols-2 md:grid-cols-6 lg:grid-cols-8">
                <TabsTrigger value="routers">Routers</TabsTrigger>
                <TabsTrigger value="interfaces">Interfaces</TabsTrigger>
                <TabsTrigger value="dhcp">DHCP</TabsTrigger>
                <TabsTrigger value="hotspot">Hotspot</TabsTrigger>
                <TabsTrigger value="firewall">Firewall</TabsTrigger>
                <TabsTrigger value="queues">Queues</TabsTrigger>
                <TabsTrigger value="vpn">VPN</TabsTrigger>
                <TabsTrigger value="tools">Tools</TabsTrigger>
              </TabsList>

              <TabsContent value="routers" className="space-y-4">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input type="search" placeholder="Search routers..." className="w-full min-w-[260px] pl-8" />
                    </div>
                    <Button variant="outline" size="sm" className="h-9">
                      <Filter className="mr-2 h-4 w-4" />
                      Filter
                    </Button>
                  </div>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Router
                  </Button>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {routers.map((router) => (
                    <Card key={router.id}>
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle>{router.name}</CardTitle>
                            <CardDescription>{router.model}</CardDescription>
                          </div>
                          <Badge
                            variant={router.status === "Online" ? "outline" : "destructive"}
                            className={router.status === "Online" ? "bg-green-50" : ""}
                          >
                            {router.status}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">IP Address:</span>
                            <span>{router.ipAddress}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Uptime:</span>
                            <span>{router.uptime}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Version:</span>
                            <span>{router.version}</span>
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">CPU Load:</span>
                              <span>{router.cpuLoad}%</span>
                            </div>
                            <Progress value={router.cpuLoad} className="h-2" />
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Memory Usage:</span>
                              <span>{router.memoryUsage}%</span>
                            </div>
                            <Progress value={router.memoryUsage} className="h-2" />
                          </div>
                          <div className="flex justify-end space-x-2 pt-2">
                            <Button variant="outline" size="sm">
                              <Terminal className="mr-2 h-4 w-4" />
                              Terminal
                            </Button>
                            <Button variant="outline" size="sm">
                              <Settings className="mr-2 h-4 w-4" />
                              Configure
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>
                                  <RefreshCw className="mr-2 h-4 w-4" /> Reboot
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <FileText className="mr-2 h-4 w-4" /> View Logs
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Save className="mr-2 h-4 w-4" /> Backup Config
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">
                                  <Trash2 className="mr-2 h-4 w-4" /> Remove
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="interfaces" className="space-y-4">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input type="search" placeholder="Search interfaces..." className="w-full min-w-[260px] pl-8" />
                    </div>
                    <Button variant="outline" size="sm" className="h-9">
                      <Filter className="mr-2 h-4 w-4" />
                      Filter
                    </Button>
                  </div>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Interface
                  </Button>
                </div>

                <div className="rounded-lg border shadow-sm">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>MAC Address</TableHead>
                        <TableHead>IP Address</TableHead>
                        <TableHead>Tx/Rx Rate</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {interfaces.map((iface) => (
                        <TableRow key={iface.id}>
                          <TableCell className="font-medium">{iface.name}</TableCell>
                          <TableCell>{iface.type}</TableCell>
                          <TableCell>{iface.macAddress}</TableCell>
                          <TableCell>{iface.ipAddress}</TableCell>
                          <TableCell>{iface.txRx}</TableCell>
                          <TableCell>
                            <Badge
                              variant={iface.status === "Running" ? "outline" : "secondary"}
                              className={iface.status === "Running" ? "bg-green-50" : ""}
                            >
                              {iface.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>View details</DropdownMenuItem>
                                <DropdownMenuItem>Edit interface</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  {iface.status === "Running" ? "Disable" : "Enable"} interface
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="dhcp" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Active Leases</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">156</div>
                      <p className="text-xs text-muted-foreground">+12 from yesterday</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">DHCP Servers</CardTitle>
                      <Server className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">3</div>
                      <p className="text-xs text-muted-foreground">All operational</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Static Leases</CardTitle>
                      <Lock className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">42</div>
                      <p className="text-xs text-muted-foreground">+5 this month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">IP Pools</CardTitle>
                      <Layers className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">5</div>
                      <p className="text-xs text-muted-foreground">No changes</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input type="search" placeholder="Search DHCP leases..." className="w-full min-w-[260px] pl-8" />
                    </div>
                    <Button variant="outline" size="sm" className="h-9">
                      <Filter className="mr-2 h-4 w-4" />
                      Filter
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Static Lease
                    </Button>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add DHCP Server
                    </Button>
                  </div>
                </div>

                <div className="rounded-lg border shadow-sm">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>MAC Address</TableHead>
                        <TableHead>IP Address</TableHead>
                        <TableHead>Hostname</TableHead>
                        <TableHead>Interface</TableHead>
                        <TableHead>Expires In</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {dhcpLeases.slice(0, 5).map((lease, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{lease.macAddress}</TableCell>
                          <TableCell>{lease.ipAddress}</TableCell>
                          <TableCell>{lease.hostname}</TableCell>
                          <TableCell>{lease.interface}</TableCell>
                          <TableCell>{lease.expiresIn}</TableCell>
                          <TableCell>
                            <Badge
                              variant={lease.status === "Active" ? "outline" : "secondary"}
                              className={lease.status === "Active" ? "bg-green-50" : ""}
                            >
                              {lease.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>View details</DropdownMenuItem>
                                <DropdownMenuItem>Make static</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">Release lease</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="hotspot" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">845</div>
                      <p className="text-xs text-muted-foreground">+78 from yesterday</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Traffic</CardTitle>
                      <Activity className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">1.2 TB</div>
                      <p className="text-xs text-muted-foreground">+150 GB from yesterday</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Active Hotspots</CardTitle>
                      <Wifi className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">12</div>
                      <p className="text-xs text-muted-foreground">All operational</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">User Profiles</CardTitle>
                      <HardDrive className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">8</div>
                      <p className="text-xs text-muted-foreground">No changes</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="search"
                        placeholder="Search hotspot users..."
                        className="w-full min-w-[260px] pl-8"
                      />
                    </div>
                    <Button variant="outline" size="sm" className="h-9">
                      <Filter className="mr-2 h-4 w-4" />
                      Filter
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline">
                      <UserPlus className="mr-2 h-4 w-4" />
                      Add User
                    </Button>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Hotspot
                    </Button>
                  </div>
                </div>

                <div className="rounded-lg border shadow-sm">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead>IP Address</TableHead>
                        <TableHead>MAC Address</TableHead>
                        <TableHead>Uptime</TableHead>
                        <TableHead>Download</TableHead>
                        <TableHead>Upload</TableHead>
                        <TableHead>Profile</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {hotspotUsers.map((user, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{user.username}</TableCell>
                          <TableCell>{user.ipAddress}</TableCell>
                          <TableCell>{user.macAddress}</TableCell>
                          <TableCell>{user.uptime}</TableCell>
                          <TableCell>{user.download}</TableCell>
                          <TableCell>{user.upload}</TableCell>
                          <TableCell>{user.profile}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>View details</DropdownMenuItem>
                                <DropdownMenuItem>Reset counters</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">Disconnect</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="firewall" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Filter Rules</CardTitle>
                      <Shield className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">48</div>
                      <p className="text-xs text-muted-foreground">+3 this week</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">NAT Rules</CardTitle>
                      <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">24</div>
                      <p className="text-xs text-muted-foreground">No changes</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Address Lists</CardTitle>
                      <Layers className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">12</div>
                      <p className="text-xs text-muted-foreground">+1 this month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Connection Tracking</CardTitle>
                      <Activity className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">15,642</div>
                      <p className="text-xs text-muted-foreground">Active connections</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="search"
                        placeholder="Search firewall rules..."
                        className="w-full min-w-[260px] pl-8"
                      />
                    </div>
                    <Select defaultValue="filter">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select rule type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="filter">Filter Rules</SelectItem>
                        <SelectItem value="nat">NAT Rules</SelectItem>
                        <SelectItem value="mangle">Mangle Rules</SelectItem>
                        <SelectItem value="raw">Raw Rules</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Rule
                  </Button>
                </div>

                <div className="rounded-lg border shadow-sm">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[50px]">Chain</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>Protocol</TableHead>
                        <TableHead>Src. Address</TableHead>
                        <TableHead>Dst. Address</TableHead>
                        <TableHead>Dst. Port</TableHead>
                        <TableHead>Comment</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {firewallRules.map((rule, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{rule.chain}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                rule.action === "accept"
                                  ? "outline"
                                  : rule.action === "drop"
                                    ? "destructive"
                                    : "secondary"
                              }
                              className={rule.action === "accept" ? "bg-green-50" : ""}
                            >
                              {rule.action}
                            </Badge>
                          </TableCell>
                          <TableCell>{rule.protocol}</TableCell>
                          <TableCell>{rule.srcAddress}</TableCell>
                          <TableCell>{rule.dstAddress}</TableCell>
                          <TableCell>{rule.dstPort}</TableCell>
                          <TableCell className="max-w-[200px] truncate">{rule.comment}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>Edit rule</DropdownMenuItem>
                                <DropdownMenuItem>Duplicate rule</DropdownMenuItem>
                                <DropdownMenuItem>Move up/down</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">Delete rule</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="queues" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Simple Queues</CardTitle>
                      <Gauge className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">156</div>
                      <p className="text-xs text-muted-foreground">+12 this month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Queue Trees</CardTitle>
                      <Layers className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">8</div>
                      <p className="text-xs text-muted-foreground">No changes</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">PCQ Queues</CardTitle>
                      <Network className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">4</div>
                      <p className="text-xs text-muted-foreground">No changes</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Bandwidth</CardTitle>
                      <Activity className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">500 Mbps</div>
                      <p className="text-xs text-muted-foreground">Allocated</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input type="search" placeholder="Search queues..." className="w-full min-w-[260px] pl-8" />
                    </div>
                    <Select defaultValue="simple">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select queue type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="simple">Simple Queues</SelectItem>
                        <SelectItem value="tree">Queue Trees</SelectItem>
                        <SelectItem value="pcq">PCQ Queues</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Queue
                  </Button>
                </div>

                <div className="rounded-lg border shadow-sm">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Target</TableHead>
                        <TableHead>Max Download</TableHead>
                        <TableHead>Max Upload</TableHead>
                        <TableHead>Current Download</TableHead>
                        <TableHead>Current Upload</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {queueRules.map((queue, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{queue.name}</TableCell>
                          <TableCell>{queue.target}</TableCell>
                          <TableCell>{queue.maxDownload}</TableCell>
                          <TableCell>{queue.maxUpload}</TableCell>
                          <TableCell>{queue.currentDownload}</TableCell>
                          <TableCell>{queue.currentUpload}</TableCell>
                          <TableCell>
                            <Badge
                              variant={queue.status === "active" ? "outline" : "secondary"}
                              className={queue.status === "active" ? "bg-green-50" : ""}
                            >
                              {queue.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>Edit queue</DropdownMenuItem>
                                <DropdownMenuItem>Reset counters</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  {queue.status === "active" ? "Disable" : "Enable"} queue
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="vpn" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Active Tunnels</CardTitle>
                      <Network className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">12</div>
                      <p className="text-xs text-muted-foreground">All operational</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">PPP Secrets</CardTitle>
                      <Key className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">245</div>
                      <p className="text-xs text-muted-foreground">+15 this month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">L2TP Clients</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">18</div>
                      <p className="text-xs text-muted-foreground">+3 from yesterday</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">PPTP Clients</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">5</div>
                      <p className="text-xs text-muted-foreground">-2 from yesterday</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input type="search" placeholder="Search VPN users..." className="w-full min-w-[260px] pl-8" />
                    </div>
                    <Select defaultValue="all">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select VPN type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All VPN Types</SelectItem>
                        <SelectItem value="l2tp">L2TP</SelectItem>
                        <SelectItem value="pptp">PPTP</SelectItem>
                        <SelectItem value="sstp">SSTP</SelectItem>
                        <SelectItem value="ovpn">OpenVPN</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add VPN User
                  </Button>
                </div>

                <div className="rounded-lg border shadow-sm">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead>Service</TableHead>
                        <TableHead>Caller ID</TableHead>
                        <TableHead>IP Address</TableHead>
                        <TableHead>Uptime</TableHead>
                        <TableHead>Download</TableHead>
                        <TableHead>Upload</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {vpnUsers.map((user, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{user.username}</TableCell>
                          <TableCell>{user.service}</TableCell>
                          <TableCell>{user.callerId}</TableCell>
                          <TableCell>{user.ipAddress}</TableCell>
                          <TableCell>{user.uptime}</TableCell>
                          <TableCell>{user.download}</TableCell>
                          <TableCell>{user.upload}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>View details</DropdownMenuItem>
                                <DropdownMenuItem>Reset counters</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">Disconnect</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="tools" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardHeader>
                      <CardTitle>Diagnostics</CardTitle>
                      <CardDescription>Network diagnostic tools</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Button variant="outline" className="w-full justify-start">
                          <Repeat className="mr-2 h-4 w-4" />
                          Ping
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Webhook className="mr-2 h-4 w-4" />
                          Traceroute
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Network className="mr-2 h-4 w-4" />
                          Bandwidth Test
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Globe className="mr-2 h-4 w-4" />
                          DNS Lookup
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>System</CardTitle>
                      <CardDescription>System management tools</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Button variant="outline" className="w-full justify-start">
                          <RefreshCw className="mr-2 h-4 w-4" />
                          Reboot
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Save className="mr-2 h-4 w-4" />
                          Backup/Restore
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <FileCode className="mr-2 h-4 w-4" />
                          Export Configuration
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Zap className="mr-2 h-4 w-4" />
                          System Resources
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Maintenance</CardTitle>
                      <CardDescription>Maintenance and update tools</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Button variant="outline" className="w-full justify-start">
                          <Wrench className="mr-2 h-4 w-4" />
                          Package Manager
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <FileText className="mr-2 h-4 w-4" />
                          Log Management
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Terminal className="mr-2 h-4 w-4" />
                          Terminal
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <AlertCircleIcon className="mr-2 h-4 w-4" />
                          System Health
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Terminal</CardTitle>
                    <CardDescription>Execute RouterOS commands directly</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-black text-green-400 font-mono p-4 rounded-md h-64 overflow-auto">
                      <div className="mb-2">[admin@MikroTik] &gt; /system resource print</div>
                      <div className="mb-2"> uptime: 45d12h36m</div>
                      <div className="mb-2"> version: 6.48.6 (stable)</div>
                      <div className="mb-2"> build-time: Apr/26/2023 11:32:59</div>
                      <div className="mb-2"> free-memory: 688.0MiB</div>
                      <div className="mb-2"> total-memory: 1200.0MiB</div>
                      <div className="mb-2"> cpu: CCR1036-12G-4S</div>
                      <div className="mb-2"> cpu-count: 36</div>
                      <div className="mb-2"> cpu-frequency: 1.2GHz</div>
                      <div className="mb-2"> cpu-load: 35%</div>
                      <div className="mb-2"> free-hdd-space: 512.0MiB</div>
                      <div className="mb-2"> total-hdd-space: 1024.0MiB</div>
                      <div className="mb-2"> bad-blocks: 0%</div>
                      <div className="mb-2"> architecture-name: tile</div>
                      <div className="mb-2"> board-name: CCR1036-12G-4S</div>
                      <div className="mb-2"> platform: MikroTik</div>
                      <div className="mb-2">[admin@MikroTik] &gt; _</div>
                    </div>
                    <div className="flex items-center mt-4">
                      <Input placeholder="Enter command..." className="font-mono" />
                      <Button className="ml-2">Execute</Button>
                    </div>
                  </CardContent>
                </Card>

                <Alert>
                  <AlertCircleIcon className="h-4 w-4" />
                  <AlertTitle>System Updates Available</AlertTitle>
                  <AlertDescription>
                    RouterOS v7.1.5 is available for your device. It is recommended to update to the latest version.
                  </AlertDescription>
                </Alert>
              </TabsContent>
            </Tabs>
          </>
        )}

        <Dialog>
          <DialogTrigger asChild>
            <Button className="hidden">Open API Documentation</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[625px]">
            <DialogHeader>
              <DialogTitle>Mikrotik API Documentation</DialogTitle>
              <DialogDescription>Reference for the Mikrotik RouterOS API commands and parameters.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="api-search">Search Commands</Label>
                <Input id="api-search" placeholder="Search API commands..." />
              </div>
              <ScrollArea className="h-72">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">/interface</h4>
                    <div className="pl-4 border-l-2 border-muted space-y-2">
                      <div className="text-sm">
                        <span className="font-mono">/interface print</span> - Show all interfaces
                      </div>
                      <div className="text-sm">
                        <span className="font-mono">/interface enable [id]</span> - Enable interface
                      </div>
                      <div className="text-sm">
                        <span className="font-mono">/interface disable [id]</span> - Disable interface
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">/ip</h4>
                    <div className="pl-4 border-l-2 border-muted space-y-2">
                      <div className="text-sm">
                        <span className="font-mono">/ip address print</span> - Show all IP addresses
                      </div>
                      <div className="text-sm">
                        <span className="font-mono">/ip route print</span> - Show all routes
                      </div>
                      <div className="text-sm">
                        <span className="font-mono">/ip firewall filter print</span> - Show firewall rules
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">/system</h4>
                    <div className="pl-4 border-l-2 border-muted space-y-2">
                      <div className="text-sm">
                        <span className="font-mono">/system resource print</span> - Show system resources
                      </div>
                      <div className="text-sm">
                        <span className="font-mono">/system reboot</span> - Reboot the router
                      </div>
                      <div className="text-sm">
                        <span className="font-mono">/system backup save</span> - Create backup
                      </div>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </div>
            <DialogFooter>
              <Button variant="outline">View Full Documentation</Button>
              <Button>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}

const routers = [
  {
    id: 1,
    name: "Core Router",
    model: "MikroTik CCR1036-12G-4S",
    status: "Online",
    ipAddress: "10.0.0.1",
    uptime: "45d 12h 36m",
    version: "6.48.6",
    cpuLoad: 35,
    memoryUsage: 42,
  },
  {
    id: 2,
    name: "Distribution Router 1",
    model: "MikroTik CCR1009-7G-1C-1S+",
    status: "Online",
    ipAddress: "10.0.0.2",
    uptime: "30d 8h 15m",
    version: "6.48.6",
    cpuLoad: 28,
    memoryUsage: 35,
  },
  {
    id: 3,
    name: "Distribution Router 2",
    model: "MikroTik CCR1009-7G-1C-1S+",
    status: "Online",
    ipAddress: "10.0.0.3",
    uptime: "15d 20h 42m",
    version: "6.48.6",
    cpuLoad: 32,
    memoryUsage: 38,
  },
  {
    id: 4,
    name: "Access Router 1",
    model: "MikroTik RB4011iGS+5HacQ2HnD",
    status: "Online",
    ipAddress: "10.0.0.4",
    uptime: "10d 14h 23m",
    version: "6.48.4",
    cpuLoad: 45,
    memoryUsage: 52,
  },
  {
    id: 5,
    name: "Access Router 2",
    model: "MikroTik RB4011iGS+5HacQ2HnD",
    status: "Online",
    ipAddress: "10.0.0.5",
    uptime: "5d 9h 17m",
    version: "6.48.4",
    cpuLoad: 38,
    memoryUsage: 45,
  },
  {
    id: 6,
    name: "Backup Router",
    model: "MikroTik CCR1036-8G-2S+",
    status: "Offline",
    ipAddress: "10.0.0.6",
    uptime: "0d 0h 0m",
    version: "6.48.6",
    cpuLoad: 0,
    memoryUsage: 0,
  },
]

const interfaces = [
  {
    id: 1,
    name: "ether1",
    router: "Core Router",
    type: "Ethernet",
    macAddress: "00:0C:29:45:67:89",
    ipAddress: "10.0.0.1/24",
    txRx: "120 Mbps / 80 Mbps",
    status: "Running",
  },
  {
    id: 2,
    name: "ether2",
    router: "Core Router",
    type: "Ethernet",
    macAddress: "00:0C:29:45:67:90",
    ipAddress: "192.168.1.1/24",
    txRx: "85 Mbps / 45 Mbps",
    status: "Running",
  },
  {
    id: 3,
    name: "sfp1",
    router: "Core Router",
    type: "SFP+",
    macAddress: "00:0C:29:45:67:91",
    ipAddress: "172.16.0.1/24",
    txRx: "450 Mbps / 320 Mbps",
    status: "Running",
  },
  {
    id: 4,
    name: "ether1",
    router: "Distribution Router 1",
    type: "Ethernet",
    macAddress: "00:0C:29:AB:CD:EF",
    ipAddress: "10.0.0.2/24",
    txRx: "95 Mbps / 65 Mbps",
    status: "Running",
  },
  {
    id: 5,
    name: "ether2",
    router: "Distribution Router 1",
    type: "Ethernet",
    macAddress: "00:0C:29:AB:CD:F0",
    ipAddress: "192.168.2.1/24",
    txRx: "75 Mbps / 40 Mbps",
    status: "Running",
  },
  {
    id: 6,
    name: "wlan1",
    router: "Access Router 1",
    type: "Wireless",
    macAddress: "00:0C:29:12:34:56",
    ipAddress: "192.168.10.1/24",
    txRx: "45 Mbps / 25 Mbps",
    status: "Running",
  },
  {
    id: 7,
    name: "ether3",
    router: "Access Router 1",
    type: "Ethernet",
    macAddress: "00:0C:29:12:34:57",
    ipAddress: "10.0.0.4/24",
    txRx: "65 Mbps / 35 Mbps",
    status: "Running",
  },
  {
    id: 8,
    name: "ether4",
    router: "Access Router 1",
    type: "Ethernet",
    macAddress: "00:0C:29:12:34:58",
    ipAddress: "Not configured",
    txRx: "0 Mbps / 0 Mbps",
    status: "Disabled",
  },
]

const dhcpLeases = [
  {
    macAddress: "00:1A:2B:3C:4D:5E",
    ipAddress: "192.168.1.100",
    hostname: "laptop-john",
    router: "Core Router",
    interface: "ether2",
    expiresIn: "23h 45m",
    status: "Active",
  },
  {
    macAddress: "00:5E:4D:3C:2B:1A",
    ipAddress: "192.168.1.101",
    hostname: "phone-emily",
    router: "Core Router",
    interface: "ether2",
    expiresIn: "22h 30m",
    status: "Active",
  },
  {
    macAddress: "00:AA:BB:CC:DD:EE",
    ipAddress: "192.168.1.102",
    hostname: "desktop-michael",
    router: "Core Router",
    interface: "ether2",
    expiresIn: "21h 15m",
    status: "Active",
  },
  {
    macAddress: "00:11:22:33:44:55",
    ipAddress: "192.168.2.100",
    hostname: "laptop-jessica",
    router: "Distribution Router 1",
    interface: "ether2",
    expiresIn: "20h 10m",
    status: "Active",
  },
  {
    macAddress: "00:66:77:88:99:AA",
    ipAddress: "192.168.2.101",
    hostname: "tablet-david",
    router: "Distribution Router 1",
    interface: "ether2",
    expiresIn: "19h 5m",
    status: "Active",
  },
]

const hotspotUsers = [
  {
    username: "guest1",
    ipAddress: "192.168.10.100",
    macAddress: "00:BB:CC:DD:EE:FF",
    uptime: "2h 15m",
    download: "1.2 GB",
    upload: "250 MB",
    profile: "Default",
  },
  {
    username: "guest2",
    ipAddress: "192.168.10.101",
    macAddress: "00:CC:DD:EE:FF:11",
    uptime: "45m",
    download: "350 MB",
    upload: "75 MB",
    profile: "Default",
  },
  {
    username: "premium1",
    ipAddress: "192.168.10.102",
    macAddress: "00:DD:EE:FF:11:22",
    uptime: "5h 30m",
    download: "3.5 GB",
    upload: "750 MB",
    profile: "Premium",
  },
  {
    username: "premium2",
    ipAddress: "192.168.10.103",
    macAddress: "00:EE:FF:11:22:33",
    uptime: "1h 20m",
    download: "850 MB",
    upload: "120 MB",
    profile: "Premium",
  },
  {
    username: "staff1",
    ipAddress: "192.168.10.104",
    macAddress: "00:FF:11:22:33:44",
    uptime: "8h 45m",
    download: "5.2 GB",
    upload: "1.1 GB",
    profile: "Staff",
  },
]

const firewallRules = [
  {
    chain: "input",
    action: "accept",
    protocol: "tcp",
    srcAddress: "0.0.0.0/0",
    dstAddress: "10.0.0.1",
    dstPort: "22,80,443",
    comment: "Allow management access",
  },
  {
    chain: "input",
    action: "drop",
    protocol: "tcp",
    srcAddress: "0.0.0.0/0",
    dstAddress: "10.0.0.1",
    dstPort: "23,25,3389",
    comment: "Block vulnerable ports",
  },
  {
    chain: "forward",
    action: "accept",
    protocol: "tcp",
    srcAddress: "192.168.1.0/24",
    dstAddress: "0.0.0.0/0",
    dstPort: "80,443",
    comment: "Allow web browsing",
  },
  {
    chain: "forward",
    action: "drop",
    protocol: "any",
    srcAddress: "192.168.1.0/24",
    dstAddress: "10.0.0.0/8",
    dstPort: "any",
    comment: "Prevent internal network access",
  },
  {
    chain: "forward",
    action: "accept",
    protocol: "udp",
    srcAddress: "192.168.1.0/24",
    dstAddress: "0.0.0.0/0",
    dstPort: "53",
    comment: "Allow DNS queries",
  },
]

const queueRules = [
  {
    name: "Customer-Premium-1",
    target: "192.168.1.100/32",
    maxDownload: "50 Mbps",
    maxUpload: "20 Mbps",
    currentDownload: "32 Mbps",
    currentUpload: "12 Mbps",
    status: "active",
  },
  {
    name: "Customer-Standard-1",
    target: "192.168.1.101/32",
    maxDownload: "25 Mbps",
    maxUpload: "10 Mbps",
    currentDownload: "18 Mbps",
    currentUpload: "5 Mbps",
    status: "active",
  },
  {
    name: "Customer-Basic-1",
    target: "192.168.1.102/32",
    maxDownload: "10 Mbps",
    maxUpload: "5 Mbps",
    currentDownload: "8 Mbps",
    currentUpload: "2 Mbps",
    status: "active",
  },
  {
    name: "Business-Gold-1",
    target: "192.168.2.100/32",
    maxDownload: "100 Mbps",
    maxUpload: "50 Mbps",
    currentDownload: "65 Mbps",
    currentUpload: "22 Mbps",
    status: "active",
  },
  {
    name: "Business-Silver-1",
    target: "192.168.2.101/32",
    maxDownload: "75 Mbps",
    maxUpload: "35 Mbps",
    currentDownload: "0 Mbps",
    currentUpload: "0 Mbps",
    status: "inactive",
  },
]

const vpnUsers = [
  {
    username: "remote1",
    service: "l2tp",
    callerId: "203.0.113.45",
    ipAddress: "10.10.10.2",
    uptime: "5h 23m",
    download: "1.2 GB",
    upload: "350 MB",
  },
  {
    username: "remote2",
    service: "pptp",
    callerId: "203.0.113.67",
    ipAddress: "10.10.10.3",
    uptime: "2h 15m",
    download: "450 MB",
    upload: "120 MB",
  },
  {
    username: "branch1",
    service: "sstp",
    callerId: "198.51.100.23",
    ipAddress: "10.10.10.4",
    uptime: "3d 12h 45m",
    download: "15.6 GB",
    upload: "4.2 GB",
  },
  {
    username: "branch2",
    service: "ovpn",
    callerId: "198.51.100.45",
    ipAddress: "10.10.10.5",
    uptime: "1d 8h 30m",
    download: "8.3 GB",
    upload: "2.1 GB",
  },
  {
    username: "admin1",
    service: "l2tp",
    callerId: "192.0.2.156",
    ipAddress: "10.10.10.6",
    uptime: "45m",
    download: "250 MB",
    upload: "75 MB",
  },
]
