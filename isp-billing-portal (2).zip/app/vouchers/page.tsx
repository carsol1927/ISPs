import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Tag,
  Clock,
  Download,
  Copy,
  Printer,
  CheckCircle2,
  XCircle,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"

export default function VouchersPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Voucher Management</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline">
              <Printer className="mr-2 h-4 w-4" />
              Print Vouchers
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Generate Vouchers
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Vouchers</CardTitle>
              <Tag className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2,845</div>
              <p className="text-xs text-muted-foreground">+245 from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Vouchers</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,245</div>
              <p className="text-xs text-muted-foreground">+156 from last week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Used Vouchers</CardTitle>
              <XCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,600</div>
              <p className="text-xs text-muted-foreground">+89 from last week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Usage Time</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">4.5 days</div>
              <p className="text-xs text-muted-foreground">+0.8 days from last month</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Vouchers</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="used">Used</TabsTrigger>
            <TabsTrigger value="expired">Expired</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search vouchers..." className="w-full min-w-[260px] pl-8" />
                </div>
                <Button variant="outline" size="sm" className="h-9">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>

            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Voucher Code</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Generated Date</TableHead>
                    <TableHead>Activation Date</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vouchers.map((voucher) => (
                    <TableRow key={voucher.code}>
                      <TableCell className="font-medium">{voucher.code}</TableCell>
                      <TableCell>{voucher.plan}</TableCell>
                      <TableCell>{voucher.duration}</TableCell>
                      <TableCell>{voucher.generatedDate}</TableCell>
                      <TableCell>{voucher.activationDate || "-"}</TableCell>
                      <TableCell>{voucher.expiryDate || "-"}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            voucher.status === "Active"
                              ? "outline"
                              : voucher.status === "Used"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {voucher.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem>
                              <Copy className="mr-2 h-4 w-4" />
                              Copy code
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Printer className="mr-2 h-4 w-4" />
                              Print voucher
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <XCircle className="mr-2 h-4 w-4" />
                              Deactivate
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious href="#" />
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">1</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#" isActive>
                    2
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">3</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
                <PaginationItem>
                  <PaginationNext href="#" />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </TabsContent>

          <TabsContent value="active" className="space-y-4">
            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Voucher Code</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Generated Date</TableHead>
                    <TableHead>Activation Date</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vouchers
                    .filter((voucher) => voucher.status === "Active")
                    .map((voucher) => (
                      <TableRow key={voucher.code}>
                        <TableCell className="font-medium">{voucher.code}</TableCell>
                        <TableCell>{voucher.plan}</TableCell>
                        <TableCell>{voucher.duration}</TableCell>
                        <TableCell>{voucher.generatedDate}</TableCell>
                        <TableCell>{voucher.activationDate || "-"}</TableCell>
                        <TableCell>{voucher.expiryDate || "-"}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <Copy className="mr-2 h-4 w-4" />
                            Copy
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="used" className="space-y-4">
            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Voucher Code</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Generated Date</TableHead>
                    <TableHead>Activation Date</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Used By</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vouchers
                    .filter((voucher) => voucher.status === "Used")
                    .map((voucher) => (
                      <TableRow key={voucher.code}>
                        <TableCell className="font-medium">{voucher.code}</TableCell>
                        <TableCell>{voucher.plan}</TableCell>
                        <TableCell>{voucher.duration}</TableCell>
                        <TableCell>{voucher.generatedDate}</TableCell>
                        <TableCell>{voucher.activationDate || "-"}</TableCell>
                        <TableCell>{voucher.expiryDate || "-"}</TableCell>
                        <TableCell>{voucher.usedBy || "-"}</TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="expired" className="space-y-4">
            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Voucher Code</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Generated Date</TableHead>
                    <TableHead>Activation Date</TableHead>
                    <TableHead>Expiry Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vouchers
                    .filter((voucher) => voucher.status === "Expired")
                    .map((voucher) => (
                      <TableRow key={voucher.code}>
                        <TableCell className="font-medium">{voucher.code}</TableCell>
                        <TableCell>{voucher.plan}</TableCell>
                        <TableCell>{voucher.duration}</TableCell>
                        <TableCell>{voucher.generatedDate}</TableCell>
                        <TableCell>{voucher.activationDate || "-"}</TableCell>
                        <TableCell>{voucher.expiryDate || "-"}</TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

const vouchers = [
  {
    code: "WIFI-4A7B-9C2D",
    plan: "Hotspot Basic",
    duration: "24 hours",
    generatedDate: "2023-05-15",
    activationDate: "2023-05-16",
    expiryDate: "2023-05-17",
    status: "Used",
    usedBy: "John Smith",
  },
  {
    code: "WIFI-5E3F-8G1H",
    plan: "Hotspot Premium",
    duration: "7 days",
    generatedDate: "2023-05-15",
    activationDate: "2023-05-17",
    expiryDate: "2023-05-24",
    status: "Active",
    usedBy: null,
  },
  {
    code: "WIFI-2J6K-7L9M",
    plan: "Hotspot Unlimited",
    duration: "30 days",
    generatedDate: "2023-05-15",
    activationDate: null,
    expiryDate: null,
    status: "Active",
    usedBy: null,
  },
  {
    code: "WIFI-3N5P-6Q8R",
    plan: "Hotspot Basic",
    duration: "24 hours",
    generatedDate: "2023-05-14",
    activationDate: "2023-05-14",
    expiryDate: "2023-05-15",
    status: "Expired",
    usedBy: "Emily Johnson",
  },
  {
    code: "WIFI-1S4T-7U9V",
    plan: "Hotspot Premium",
    duration: "7 days",
    generatedDate: "2023-05-14",
    activationDate: "2023-05-14",
    expiryDate: "2023-05-21",
    status: "Active",
    usedBy: null,
  },
  {
    code: "WIFI-2W5X-8Y1Z",
    plan: "Hotspot Basic",
    duration: "24 hours",
    generatedDate: "2023-05-13",
    activationDate: "2023-05-13",
    expiryDate: "2023-05-14",
    status: "Used",
    usedBy: "Michael Williams",
  },
  {
    code: "WIFI-9A3B-5C7D",
    plan: "Hotspot Unlimited",
    duration: "30 days",
    generatedDate: "2023-05-13",
    activationDate: "2023-05-13",
    expiryDate: "2023-06-12",
    status: "Active",
    usedBy: null,
  },
  {
    code: "WIFI-8E2F-4G6H",
    plan: "Hotspot Basic",
    duration: "24 hours",
    generatedDate: "2023-05-12",
    activationDate: "2023-05-12",
    expiryDate: "2023-05-13",
    status: "Expired",
    usedBy: "Jessica Brown",
  },
  {
    code: "WIFI-7J1K-3L5M",
    plan: "Hotspot Premium",
    duration: "7 days",
    generatedDate: "2023-05-12",
    activationDate: "2023-05-12",
    expiryDate: "2023-05-19",
    status: "Active",
    usedBy: null,
  },
  {
    code: "WIFI-6N9P-2Q4R",
    plan: "Hotspot Basic",
    duration: "24 hours",
    generatedDate: "2023-05-11",
    activationDate: "2023-05-11",
    expiryDate: "2023-05-12",
    status: "Used",
    usedBy: "David Miller",
  },
]
