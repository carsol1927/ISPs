import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Plus, Search, Filter, MoreHorizontal, Download, Edit, Trash2, Eye } from "lucide-react"

export default function CustomersPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Customers</h1>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Customer
        </Button>
      </div>

      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="Search customers..." className="w-full min-w-[260px] pl-8" />
          </div>
          <Button variant="outline" size="sm" className="h-9">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="rounded-lg border shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Plan</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {customers.map((customer) => (
              <TableRow key={customer.id}>
                <TableCell className="font-medium">{customer.id}</TableCell>
                <TableCell>{customer.name}</TableCell>
                <TableCell>{customer.email}</TableCell>
                <TableCell>{customer.phone}</TableCell>
                <TableCell>{customer.plan}</TableCell>
                <TableCell>
                  <Badge variant={customer.status === "Active" ? "outline" : "secondary"}>{customer.status}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem>
                        <Eye className="mr-2 h-4 w-4" />
                        View details
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" />
                        Edit customer
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete customer
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Pagination>
        <PaginationContent>
          <PaginationItem>
            <PaginationPrevious href="#" />
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href="#">1</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href="#" isActive>
              2
            </PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href="#">3</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationEllipsis />
          </PaginationItem>
          <PaginationItem>
            <PaginationNext href="#" />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
    </div>
  )
}

const customers = [
  {
    id: "CUST001",
    name: "John Smith",
    email: "john.smith@example.com",
    phone: "(555) 123-4567",
    plan: "Fiber 1Gbps",
    status: "Active",
  },
  {
    id: "CUST002",
    name: "Emily Johnson",
    email: "emily.johnson@example.com",
    phone: "(555) 234-5678",
    plan: "Cable 500Mbps",
    status: "Active",
  },
  {
    id: "CUST003",
    name: "Michael Williams",
    email: "michael.williams@example.com",
    phone: "(555) 345-6789",
    plan: "DSL 100Mbps",
    status: "Inactive",
  },
  {
    id: "CUST004",
    name: "Jessica Brown",
    email: "jessica.brown@example.com",
    phone: "(555) 456-7890",
    plan: "Fiber 500Mbps",
    status: "Active",
  },
  {
    id: "CUST005",
    name: "David Miller",
    email: "david.miller@example.com",
    phone: "(555) 567-8901",
    plan: "Business Fiber 2Gbps",
    status: "Active",
  },
  {
    id: "CUST006",
    name: "Sarah Davis",
    email: "sarah.davis@example.com",
    phone: "(555) 678-9012",
    plan: "Cable 250Mbps",
    status: "Suspended",
  },
  {
    id: "CUST007",
    name: "Robert Wilson",
    email: "robert.wilson@example.com",
    phone: "(555) 789-0123",
    plan: "Fiber 1Gbps",
    status: "Active",
  },
  {
    id: "CUST008",
    name: "Jennifer Taylor",
    email: "jennifer.taylor@example.com",
    phone: "(555) 890-1234",
    plan: "DSL 50Mbps",
    status: "Inactive",
  },
  {
    id: "CUST009",
    name: "Thomas Anderson",
    email: "thomas.anderson@example.com",
    phone: "(555) 901-2345",
    plan: "Business Fiber 1Gbps",
    status: "Active",
  },
  {
    id: "CUST010",
    name: "Lisa Martinez",
    email: "lisa.martinez@example.com",
    phone: "(555) 012-3456",
    plan: "Cable 100Mbps",
    status: "Active",
  },
]
