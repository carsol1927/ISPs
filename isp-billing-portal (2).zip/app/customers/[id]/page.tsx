import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  CreditCard,
  FileText,
  Wifi,
  ArrowLeft,
  Edit,
  Trash2,
  Download,
} from "lucide-react"
import Link from "next/link"

export default function CustomerDetailPage({ params }: { params: { id: string } }) {
  // In a real application, you would fetch customer data based on the ID
  const customerId = params.id

  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center gap-4">
          <Link href="/customers">
            <Button variant="outline" size="icon" className="h-7 w-7">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-semibold">Customer Details</h1>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="outline">
              <Edit className="mr-2 h-4 w-4" />
              Edit Customer
            </Button>
            <Button variant="destructive">
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </Button>
          </div>
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                    <User className="h-8 w-8" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">John Smith</CardTitle>
                    <CardDescription>Customer ID: {customerId}</CardDescription>
                  </div>
                </div>
                <Badge className="mt-1">Active</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div className="text-sm">john.smith@example.com</div>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <div className="text-sm">(555) 123-4567</div>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div className="text-sm">123 Main St, Anytown, USA</div>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div className="text-sm">Customer since: Jan 15, 2023</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="services" className="space-y-4">
            <TabsList>
              <TabsTrigger value="services">Services</TabsTrigger>
              <TabsTrigger value="billing">Billing</TabsTrigger>
              <TabsTrigger value="equipment">Equipment</TabsTrigger>
              <TabsTrigger value="support">Support History</TabsTrigger>
            </TabsList>

            <TabsContent value="services" className="space-y-4">
              <div className="flex justify-between">
                <h2 className="text-lg font-medium">Active Services</h2>
                <Button>
                  <Wifi className="mr-2 h-4 w-4" />
                  Add Service
                </Button>
              </div>

              <div className="rounded-lg border shadow-sm">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">Service ID</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Installation Date</TableHead>
                      <TableHead>Monthly Fee</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">SRV001</TableCell>
                      <TableCell>Fiber 1Gbps</TableCell>
                      <TableCell>Jan 15, 2023</TableCell>
                      <TableCell>$129.99</TableCell>
                      <TableCell>
                        <Badge variant="outline">Active</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          Manage
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="billing" className="space-y-4">
              <div className="flex justify-between">
                <h2 className="text-lg font-medium">Billing Information</h2>
                <Button>
                  <CreditCard className="mr-2 h-4 w-4" />
                  Process Payment
                </Button>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Method</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4">
                      <div className="flex h-10 w-16 items-center justify-center rounded-md border bg-muted">
                        <CreditCard className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Visa ending in 4567</p>
                        <p className="text-xs text-muted-foreground">Expires 05/2025</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Billing Address</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">John Smith</p>
                    <p className="text-sm">123 Main St</p>
                    <p className="text-sm">Anytown, USA 12345</p>
                  </CardContent>
                </Card>
              </div>

              <div className="rounded-lg border shadow-sm">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">Invoice #</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">INV-2023-001</TableCell>
                      <TableCell>May 1, 2023</TableCell>
                      <TableCell>May 15, 2023</TableCell>
                      <TableCell>$129.99</TableCell>
                      <TableCell>
                        <Badge variant="outline">Paid</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <FileText className="mr-2 h-4 w-4" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">INV-2023-002</TableCell>
                      <TableCell>Apr 1, 2023</TableCell>
                      <TableCell>Apr 15, 2023</TableCell>
                      <TableCell>$129.99</TableCell>
                      <TableCell>
                        <Badge variant="outline">Paid</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <FileText className="mr-2 h-4 w-4" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">INV-2023-003</TableCell>
                      <TableCell>Mar 1, 2023</TableCell>
                      <TableCell>Mar 15, 2023</TableCell>
                      <TableCell>$129.99</TableCell>
                      <TableCell>
                        <Badge variant="outline">Paid</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <FileText className="mr-2 h-4 w-4" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div className="flex justify-end">
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Download All Invoices
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="equipment" className="space-y-4">
              <div className="flex justify-between">
                <h2 className="text-lg font-medium">Assigned Equipment</h2>
                <Button>Add Equipment</Button>
              </div>

              <div className="rounded-lg border shadow-sm">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">Equipment ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Model</TableHead>
                      <TableHead>Serial Number</TableHead>
                      <TableHead>Installation Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">EQP001</TableCell>
                      <TableCell>Router</TableCell>
                      <TableCell>Cisco 2900</TableCell>
                      <TableCell>CSC29001234</TableCell>
                      <TableCell>Jan 15, 2023</TableCell>
                      <TableCell>
                        <Badge variant="outline">Deployed</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">EQP002</TableCell>
                      <TableCell>Modem</TableCell>
                      <TableCell>Arris SB8200</TableCell>
                      <TableCell>ARR82001234</TableCell>
                      <TableCell>Jan 15, 2023</TableCell>
                      <TableCell>
                        <Badge variant="outline">Deployed</Badge>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="support" className="space-y-4">
              <div className="flex justify-between">
                <h2 className="text-lg font-medium">Support History</h2>
                <Button>Create Ticket</Button>
              </div>

              <div className="rounded-lg border shadow-sm">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">Ticket ID</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">TKT001</TableCell>
                      <TableCell>Internet connection issues</TableCell>
                      <TableCell>Mar 10, 2023</TableCell>
                      <TableCell>
                        <Badge variant="outline">Resolved</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">TKT002</TableCell>
                      <TableCell>Billing inquiry</TableCell>
                      <TableCell>Feb 5, 2023</TableCell>
                      <TableCell>
                        <Badge variant="outline">Resolved</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
