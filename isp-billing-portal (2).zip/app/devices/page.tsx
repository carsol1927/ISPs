"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Progress } from "@/components/ui/progress"
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Activity,
  RefreshCw,
  Settings,
  AlertCircle,
  Laptop,
  Signal,
  Trash2,
  Edit,
  Eye,
  MapPin,
  BarChart3,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useState } from "react"

export default function DevicesPage() {
  const [showAddDeviceForm, setShowAddDeviceForm] = useState(false)
  const [activeTab, setActiveTab] = useState("all")

  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Device Management</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh Status
            </Button>
            <Button onClick={() => setShowAddDeviceForm(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Device
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Devices</CardTitle>
              <Laptop className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">248</div>
              <p className="text-xs text-muted-foreground">+12 from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Online Devices</CardTitle>
              <Signal className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">186</div>
              <p className="text-xs text-muted-foreground">75% of total devices</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Bandwidth Usage</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1.8 TB</div>
              <p className="text-xs text-muted-foreground">Last 30 days</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Alerts</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5</div>
              <p className="text-xs text-muted-foreground">+2 from yesterday</p>
            </CardContent>
          </Card>
        </div>

        {showAddDeviceForm && (
          <Card>
            <CardHeader>
              <CardTitle>Add New Device</CardTitle>
              <CardDescription>Enter the details of the device you want to add to your network.</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Device Name</Label>
                    <Input id="name" placeholder="Office Laptop" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Device Type</Label>
                    <Select defaultValue="laptop">
                      <SelectTrigger id="type">
                        <SelectValue placeholder="Select device type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="laptop">Laptop</SelectItem>
                        <SelectItem value="desktop">Desktop</SelectItem>
                        <SelectItem value="smartphone">Smartphone</SelectItem>
                        <SelectItem value="tablet">Tablet</SelectItem>
                        <SelectItem value="router">Router</SelectItem>
                        <SelectItem value="switch">Switch</SelectItem>
                        <SelectItem value="accesspoint">Access Point</SelectItem>
                        <SelectItem value="printer">Printer</SelectItem>
                        <SelectItem value="camera">Camera</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mac">MAC Address</Label>
                    <Input id="mac" placeholder="00:1A:2B:3C:4D:5E" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ip">IP Address</Label>
                    <Input id="ip" placeholder="192.168.1.100" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input id="location" placeholder="Main Office" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="owner">Owner/User</Label>
                    <Input id="owner" placeholder="John Doe" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Input id="notes" placeholder="Additional information" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="group">Device Group</Label>
                    <Select defaultValue="default">
                      <SelectTrigger id="group">
                        <SelectValue placeholder="Select group" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Default</SelectItem>
                        <SelectItem value="office">Office</SelectItem>
                        <SelectItem value="home">Home</SelectItem>
                        <SelectItem value="mobile">Mobile</SelectItem>
                        <SelectItem value="iot">IoT</SelectItem>
                        <SelectItem value="network">Network Infrastructure</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="monitor" />
                    <label
                      htmlFor="monitor"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Enable monitoring for this device
                    </label>
                  </div>
                </div>
              </form>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setShowAddDeviceForm(false)}>
                Cancel
              </Button>
              <Button onClick={() => setShowAddDeviceForm(false)}>Add Device</Button>
            </CardFooter>
          </Card>
        )}

        <Tabs defaultValue="all" className="space-y-4" onValueChange={setActiveTab}>
          <div className="flex justify-between items-center">
            <TabsList>
              <TabsTrigger value="all">All Devices</TabsTrigger>
              <TabsTrigger value="network">Network</TabsTrigger>
              <TabsTrigger value="computers">Computers</TabsTrigger>
              <TabsTrigger value="mobile">Mobile</TabsTrigger>
              <TabsTrigger value="iot">IoT</TabsTrigger>
            </TabsList>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search devices..." className="w-full min-w-[260px] pl-8" />
              </div>
              <Button variant="outline" size="sm" className="h-9">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>
          </div>

          <TabsContent value="all" className="space-y-4">
            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[80px]">Status</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>MAC Address</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Last Seen</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {devices.map((device) => (
                    <TableRow key={device.id}>
                      <TableCell>
                        <Badge
                          variant={device.status === "Online" ? "outline" : "secondary"}
                          className={device.status === "Online" ? "bg-green-50" : ""}
                        >
                          {device.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">{device.name}</TableCell>
                      <TableCell>{device.type}</TableCell>
                      <TableCell>{device.ipAddress}</TableCell>
                      <TableCell>{device.macAddress}</TableCell>
                      <TableCell>{device.location}</TableCell>
                      <TableCell>{device.lastSeen}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" /> View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" /> Edit Device
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Activity className="mr-2 h-4 w-4" /> View Traffic
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="mr-2 h-4 w-4" /> Remove Device
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="network" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {devices
                .filter((device) => ["Router", "Switch", "Access Point"].includes(device.type))
                .map((device) => (
                  <Card key={device.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{device.name}</CardTitle>
                          <CardDescription>{device.type}</CardDescription>
                        </div>
                        <Badge
                          variant={device.status === "Online" ? "outline" : "secondary"}
                          className={device.status === "Online" ? "bg-green-50" : ""}
                        >
                          {device.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">IP Address:</span>
                          <span>{device.ipAddress}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">MAC Address:</span>
                          <span>{device.macAddress}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Location:</span>
                          <span>{device.location}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Last Seen:</span>
                          <span>{device.lastSeen}</span>
                        </div>
                        {device.status === "Online" && (
                          <>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">CPU Load:</span>
                                <span>{device.cpuLoad || "35"}%</span>
                              </div>
                              <Progress value={device.cpuLoad || 35} className="h-2" />
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Memory Usage:</span>
                                <span>{device.memoryUsage || "42"}%</span>
                              </div>
                              <Progress value={device.memoryUsage || 42} className="h-2" />
                            </div>
                          </>
                        )}
                        <div className="flex justify-end space-x-2 pt-2">
                          <Button variant="outline" size="sm">
                            <Settings className="mr-2 h-4 w-4" />
                            Configure
                          </Button>
                          <Button variant="outline" size="sm">
                            <Activity className="mr-2 h-4 w-4" />
                            Traffic
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="computers" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {devices
                .filter((device) => ["Desktop", "Laptop", "Server"].includes(device.type))
                .map((device) => (
                  <Card key={device.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{device.name}</CardTitle>
                          <CardDescription>{device.type}</CardDescription>
                        </div>
                        <Badge
                          variant={device.status === "Online" ? "outline" : "secondary"}
                          className={device.status === "Online" ? "bg-green-50" : ""}
                        >
                          {device.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">IP Address:</span>
                          <span>{device.ipAddress}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">MAC Address:</span>
                          <span>{device.macAddress}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Owner:</span>
                          <span>{device.owner || "N/A"}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Last Seen:</span>
                          <span>{device.lastSeen}</span>
                        </div>
                        {device.status === "Online" && (
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Bandwidth Usage:</span>
                              <span>{device.bandwidth || "125 MB"}/day</span>
                            </div>
                            <Progress value={45} className="h-2" />
                          </div>
                        )}
                        <div className="flex justify-end space-x-2 pt-2">
                          <Button variant="outline" size="sm">
                            <Eye className="mr-2 h-4 w-4" />
                            Details
                          </Button>
                          <Button variant="outline" size="sm">
                            <Activity className="mr-2 h-4 w-4" />
                            Traffic
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="mobile" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {devices
                .filter((device) => ["Smartphone", "Tablet"].includes(device.type))
                .map((device) => (
                  <Card key={device.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{device.name}</CardTitle>
                          <CardDescription>{device.type}</CardDescription>
                        </div>
                        <Badge
                          variant={device.status === "Online" ? "outline" : "secondary"}
                          className={device.status === "Online" ? "bg-green-50" : ""}
                        >
                          {device.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">IP Address:</span>
                          <span>{device.ipAddress}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">MAC Address:</span>
                          <span>{device.macAddress}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Owner:</span>
                          <span>{device.owner || "N/A"}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Last Seen:</span>
                          <span>{device.lastSeen}</span>
                        </div>
                        {device.status === "Online" && (
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Bandwidth Usage:</span>
                              <span>{device.bandwidth || "85 MB"}/day</span>
                            </div>
                            <Progress value={35} className="h-2" />
                          </div>
                        )}
                        <div className="flex justify-end space-x-2 pt-2">
                          <Button variant="outline" size="sm">
                            <Eye className="mr-2 h-4 w-4" />
                            Details
                          </Button>
                          <Button variant="outline" size="sm">
                            <Activity className="mr-2 h-4 w-4" />
                            Traffic
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="iot" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {devices
                .filter((device) => ["Camera", "Printer", "Smart TV", "IoT Device"].includes(device.type))
                .map((device) => (
                  <Card key={device.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{device.name}</CardTitle>
                          <CardDescription>{device.type}</CardDescription>
                        </div>
                        <Badge
                          variant={device.status === "Online" ? "outline" : "secondary"}
                          className={device.status === "Online" ? "bg-green-50" : ""}
                        >
                          {device.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">IP Address:</span>
                          <span>{device.ipAddress}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">MAC Address:</span>
                          <span>{device.macAddress}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Location:</span>
                          <span>{device.location}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Last Seen:</span>
                          <span>{device.lastSeen}</span>
                        </div>
                        {device.status === "Online" && (
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Bandwidth Usage:</span>
                              <span>{device.bandwidth || "45 MB"}/day</span>
                            </div>
                            <Progress value={25} className="h-2" />
                          </div>
                        )}
                        <div className="flex justify-end space-x-2 pt-2">
                          <Button variant="outline" size="sm">
                            <Eye className="mr-2 h-4 w-4" />
                            Details
                          </Button>
                          <Button variant="outline" size="sm">
                            <Settings className="mr-2 h-4 w-4" />
                            Configure
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>
        </Tabs>

        {activeTab === "all" && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Device Types</CardTitle>
                <CardDescription>Distribution of devices by type</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <div className="h-[200px] w-full bg-muted/20 rounded-md flex items-center justify-center">
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    <BarChart3 className="h-8 w-8" />
                    <span>Device Type Distribution</span>
                    <div className="grid grid-cols-2 gap-x-8 gap-y-1 text-xs">
                      <div className="flex items-center">
                        <div className="h-2 w-2 rounded-full bg-blue-500 mr-1"></div>
                        <span>Laptops (28%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="h-2 w-2 rounded-full bg-green-500 mr-1"></div>
                        <span>Smartphones (22%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="h-2 w-2 rounded-full bg-yellow-500 mr-1"></div>
                        <span>Desktops (18%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="h-2 w-2 rounded-full bg-purple-500 mr-1"></div>
                        <span>IoT Devices (15%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="h-2 w-2 rounded-full bg-red-500 mr-1"></div>
                        <span>Network (10%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="h-2 w-2 rounded-full bg-gray-500 mr-1"></div>
                        <span>Others (7%)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Bandwidth Usage</CardTitle>
                <CardDescription>Top bandwidth consumers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {devices
                    .filter((device) => device.status === "Online")
                    .slice(0, 5)
                    .map((device) => (
                      <div key={device.id} className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <div className="font-medium">{device.name}</div>
                          <div>{device.bandwidth || "125 MB"}/day</div>
                        </div>
                        <Progress value={Math.floor(Math.random() * 80) + 20} className="h-2" />
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Device Locations</CardTitle>
                <CardDescription>Where your devices are located</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>Main Office</span>
                    </div>
                    <Badge>125 devices</Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>Branch Office</span>
                    </div>
                    <Badge>68 devices</Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>Remote Workers</span>
                    </div>
                    <Badge>42 devices</Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>Data Center</span>
                    </div>
                    <Badge>13 devices</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Sheet>
          <SheetTrigger asChild>
            <Button className="hidden">View Device Details</Button>
          </SheetTrigger>
          <SheetContent className="sm:max-w-[540px]">
            <SheetHeader>
              <SheetTitle>Device Details</SheetTitle>
              <SheetDescription>Detailed information about the selected device.</SheetDescription>
            </SheetHeader>
            <div className="py-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Office Laptop</h3>
                  <Badge variant="outline" className="bg-green-50">
                    Online
                  </Badge>
                </div>
                <Separator />
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Device Type</h4>
                    <p>Laptop</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">IP Address</h4>
                    <p>192.168.1.100</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">MAC Address</h4>
                    <p>00:1A:2B:3C:4D:5E</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Location</h4>
                    <p>Main Office</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Owner</h4>
                    <p>John Doe</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Last Seen</h4>
                    <p>Just now</p>
                  </div>
                </div>
                <Separator />
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Bandwidth Usage</h4>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Today</span>
                      <span>125 MB</span>
                    </div>
                    <Progress value={45} className="h-2" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">This Week</span>
                      <span>1.2 GB</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">This Month</span>
                      <span>5.8 GB</span>
                    </div>
                    <Progress value={35} className="h-2" />
                  </div>
                </div>
                <Separator />
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Connection History</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>May 22, 2023 - 08:15 AM</span>
                      <span className="text-green-600">Connected</span>
                    </div>
                    <div className="flex justify-between">
                      <span>May 21, 2023 - 06:30 PM</span>
                      <span className="text-red-600">Disconnected</span>
                    </div>
                    <div className="flex justify-between">
                      <span>May 21, 2023 - 09:45 AM</span>
                      <span className="text-green-600">Connected</span>
                    </div>
                    <div className="flex justify-between">
                      <span>May 20, 2023 - 07:20 PM</span>
                      <span className="text-red-600">Disconnected</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-4">
              <Button variant="outline">
                <Activity className="mr-2 h-4 w-4" />
                View Traffic
              </Button>
              <Button>
                <Settings className="mr-2 h-4 w-4" />
                Configure
              </Button>
            </div>
          </SheetContent>
        </Sheet>

        <Dialog>
          <DialogTrigger asChild>
            <Button className="hidden">Edit Device</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[625px]">
            <DialogHeader>
              <DialogTitle>Edit Device</DialogTitle>
              <DialogDescription>Make changes to the device information.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Device Name</Label>
                  <Input id="edit-name" defaultValue="Office Laptop" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-type">Device Type</Label>
                  <Select defaultValue="laptop">
                    <SelectTrigger id="edit-type">
                      <SelectValue placeholder="Select device type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="laptop">Laptop</SelectItem>
                      <SelectItem value="desktop">Desktop</SelectItem>
                      <SelectItem value="smartphone">Smartphone</SelectItem>
                      <SelectItem value="tablet">Tablet</SelectItem>
                      <SelectItem value="router">Router</SelectItem>
                      <SelectItem value="switch">Switch</SelectItem>
                      <SelectItem value="accesspoint">Access Point</SelectItem>
                      <SelectItem value="printer">Printer</SelectItem>
                      <SelectItem value="camera">Camera</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-mac">MAC Address</Label>
                  <Input id="edit-mac" defaultValue="00:1A:2B:3C:4D:5E" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-ip">IP Address</Label>
                  <Input id="edit-ip" defaultValue="192.168.1.100" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-location">Location</Label>
                  <Input id="edit-location" defaultValue="Main Office" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-owner">Owner/User</Label>
                  <Input id="edit-owner" defaultValue="John Doe" />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="edit-notes">Notes</Label>
                  <Input id="edit-notes" defaultValue="Employee laptop, Dell XPS 15" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox id="edit-monitor" defaultChecked />
                  <label
                    htmlFor="edit-monitor"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Enable monitoring for this device
                  </label>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline">Cancel</Button>
              <Button>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}

const devices = [
  {
    id: 1,
    name: "Core Router",
    type: "Router",
    ipAddress: "10.0.0.1",
    macAddress: "00:0C:29:45:67:89",
    location: "Main Office",
    lastSeen: "Just now",
    status: "Online",
    cpuLoad: 35,
    memoryUsage: 42,
  },
  {
    id: 2,
    name: "Office Laptop",
    type: "Laptop",
    ipAddress: "192.168.1.100",
    macAddress: "00:1A:2B:3C:4D:5E",
    location: "Main Office",
    lastSeen: "Just now",
    status: "Online",
    owner: "John Doe",
    bandwidth: "125 MB",
  },
  {
    id: 3,
    name: "Reception Desk PC",
    type: "Desktop",
    ipAddress: "192.168.1.101",
    macAddress: "00:5E:4D:3C:2B:1A",
    location: "Main Office",
    lastSeen: "Just now",
    status: "Online",
    owner: "Emily Johnson",
    bandwidth: "95 MB",
  },
  {
    id: 4,
    name: "CEO's iPhone",
    type: "Smartphone",
    ipAddress: "192.168.1.102",
    macAddress: "00:AA:BB:CC:DD:EE",
    location: "Main Office",
    lastSeen: "5 minutes ago",
    status: "Online",
    owner: "Michael Smith",
    bandwidth: "85 MB",
  },
  {
    id: 5,
    name: "Conference Room AP",
    type: "Access Point",
    ipAddress: "192.168.1.5",
    macAddress: "00:11:22:33:44:55",
    location: "Main Office",
    lastSeen: "Just now",
    status: "Online",
    cpuLoad: 28,
    memoryUsage: 35,
  },
  {
    id: 6,
    name: "Marketing iPad",
    type: "Tablet",
    ipAddress: "192.168.1.103",
    macAddress: "00:66:77:88:99:AA",
    location: "Main Office",
    lastSeen: "15 minutes ago",
    status: "Online",
    owner: "Jessica Lee",
    bandwidth: "65 MB",
  },
  {
    id: 7,
    name: "Office Printer",
    type: "Printer",
    ipAddress: "192.168.1.10",
    macAddress: "00:BB:CC:DD:EE:FF",
    location: "Main Office",
    lastSeen: "Just now",
    status: "Online",
    bandwidth: "15 MB",
  },
  {
    id: 8,
    name: "Security Camera 1",
    type: "Camera",
    ipAddress: "192.168.1.20",
    macAddress: "00:CC:DD:EE:FF:11",
    location: "Main Office",
    lastSeen: "Just now",
    status: "Online",
    bandwidth: "120 MB",
  },
  {
    id: 9,
    name: "Branch Office Switch",
    type: "Switch",
    ipAddress: "10.0.1.1",
    macAddress: "00:DD:EE:FF:11:22",
    location: "Branch Office",
    lastSeen: "Just now",
    status: "Online",
    cpuLoad: 25,
    memoryUsage: 30,
  },
  {
    id: 10,
    name: "Developer Workstation",
    type: "Desktop",
    ipAddress: "192.168.1.104",
    macAddress: "00:EE:FF:11:22:33",
    location: "Main Office",
    lastSeen: "3 hours ago",
    status: "Offline",
    owner: "David Wilson",
  },
  {
    id: 11,
    name: "Meeting Room TV",
    type: "Smart TV",
    ipAddress: "192.168.1.30",
    macAddress: "00:FF:11:22:33:44",
    location: "Main Office",
    lastSeen: "2 hours ago",
    status: "Offline",
  },
  {
    id: 12,
    name: "File Server",
    type: "Server",
    ipAddress: "10.0.0.5",
    macAddress: "00:12:34:56:78:9A",
    location: "Main Office",
    lastSeen: "Just now",
    status: "Online",
    cpuLoad: 45,
    memoryUsage: 65,
    bandwidth: "350 MB",
  },
]
