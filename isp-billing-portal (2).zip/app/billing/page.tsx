import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Plus, Search, Filter, MoreHorizontal, Download, Printer, Send, Eye, CreditCard } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function BillingPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Billing & Invoices</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline">
              <CreditCard className="mr-2 h-4 w-4" />
              Process Payments
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Invoice
            </Button>
          </div>
        </div>

        <Tabs defaultValue="invoices" className="space-y-4">
          <TabsList>
            <TabsTrigger value="invoices">Invoices</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="plans">Service Plans</TabsTrigger>
          </TabsList>

          <TabsContent value="invoices" className="space-y-4">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search invoices..." className="w-full min-w-[260px] pl-8" />
                </div>
                <Button variant="outline" size="sm" className="h-9">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>

            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Invoice #</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell className="font-medium">{invoice.id}</TableCell>
                      <TableCell>{invoice.customer}</TableCell>
                      <TableCell>{invoice.date}</TableCell>
                      <TableCell>{invoice.dueDate}</TableCell>
                      <TableCell>${invoice.amount}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            invoice.status === "Paid"
                              ? "outline"
                              : invoice.status === "Overdue"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {invoice.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View invoice
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Send className="mr-2 h-4 w-4" />
                              Send to customer
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Printer className="mr-2 h-4 w-4" />
                              Print invoice
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <CreditCard className="mr-2 h-4 w-4" />
                              Mark as paid
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious href="#" />
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">1</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#" isActive>
                    2
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink href="#">3</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
                <PaginationItem>
                  <PaginationNext href="#" />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </TabsContent>

          <TabsContent value="payments" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$42,530.75</div>
                  <p className="text-xs text-muted-foreground">+20.1% from last month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$6,218.42</div>
                  <p className="text-xs text-muted-foreground">+4.5% from last week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Overdue Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$2,408.50</div>
                  <p className="text-xs text-muted-foreground">-2.5% from last week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Failed Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$890.25</div>
                  <p className="text-xs text-muted-foreground">+0.3% from last week</p>
                </CardContent>
              </Card>
            </div>

            <div className="rounded-lg border shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Payment ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell className="font-medium">{payment.id}</TableCell>
                      <TableCell>{payment.customer}</TableCell>
                      <TableCell>{payment.date}</TableCell>
                      <TableCell>{payment.method}</TableCell>
                      <TableCell>${payment.amount}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            payment.status === "Completed"
                              ? "outline"
                              : payment.status === "Failed"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {payment.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Eye className="mr-2 h-4 w-4" />
                          Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="plans" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium">Service Plans</h2>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Plan
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {servicePlans.map((plan) => (
                <Card key={plan.id}>
                  <CardHeader>
                    <CardTitle>{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold mb-2">
                      ${plan.price}
                      <span className="text-sm font-normal text-muted-foreground">/month</span>
                    </div>
                    <ul className="space-y-2 mb-4">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-center">
                          <span className="mr-2">✓</span> {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="flex justify-between items-center">
                      <Badge>{plan.customers} customers</Badge>
                      <Button variant="outline" size="sm">
                        Edit Plan
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

const invoices = [
  {
    id: "INV-2023-001",
    customer: "John Smith",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "129.99",
    status: "Paid",
  },
  {
    id: "INV-2023-002",
    customer: "Emily Johnson",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "89.99",
    status: "Paid",
  },
  {
    id: "INV-2023-003",
    customer: "Michael Williams",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "59.99",
    status: "Overdue",
  },
  {
    id: "INV-2023-004",
    customer: "Jessica Brown",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "99.99",
    status: "Paid",
  },
  {
    id: "INV-2023-005",
    customer: "David Miller",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "199.99",
    status: "Pending",
  },
  {
    id: "INV-2023-006",
    customer: "Sarah Davis",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "79.99",
    status: "Pending",
  },
  {
    id: "INV-2023-007",
    customer: "Robert Wilson",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "129.99",
    status: "Paid",
  },
  {
    id: "INV-2023-008",
    customer: "Jennifer Taylor",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "49.99",
    status: "Overdue",
  },
  {
    id: "INV-2023-009",
    customer: "Thomas Anderson",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "149.99",
    status: "Paid",
  },
  {
    id: "INV-2023-010",
    customer: "Lisa Martinez",
    date: "2023-05-01",
    dueDate: "2023-05-15",
    amount: "69.99",
    status: "Pending",
  },
]

const payments = [
  {
    id: "PAY-2023-001",
    customer: "John Smith",
    date: "2023-05-10",
    method: "Credit Card",
    amount: "129.99",
    status: "Completed",
  },
  {
    id: "PAY-2023-002",
    customer: "Emily Johnson",
    date: "2023-05-12",
    method: "Bank Transfer",
    amount: "89.99",
    status: "Completed",
  },
  {
    id: "PAY-2023-003",
    customer: "Jessica Brown",
    date: "2023-05-14",
    method: "Credit Card",
    amount: "99.99",
    status: "Completed",
  },
  {
    id: "PAY-2023-004",
    customer: "Robert Wilson",
    date: "2023-05-15",
    method: "PayPal",
    amount: "129.99",
    status: "Completed",
  },
  {
    id: "PAY-2023-005",
    customer: "Thomas Anderson",
    date: "2023-05-15",
    method: "Credit Card",
    amount: "149.99",
    status: "Completed",
  },
  {
    id: "PAY-2023-006",
    customer: "Michael Williams",
    date: "2023-05-16",
    method: "Credit Card",
    amount: "59.99",
    status: "Failed",
  },
  {
    id: "PAY-2023-007",
    customer: "David Miller",
    date: "2023-05-16",
    method: "Bank Transfer",
    amount: "199.99",
    status: "Pending",
  },
  {
    id: "PAY-2023-008",
    customer: "Sarah Davis",
    date: "2023-05-17",
    method: "PayPal",
    amount: "79.99",
    status: "Pending",
  },
  {
    id: "PAY-2023-009",
    customer: "Jennifer Taylor",
    date: "2023-05-17",
    method: "Credit Card",
    amount: "49.99",
    status: "Failed",
  },
  {
    id: "PAY-2023-010",
    customer: "Lisa Martinez",
    date: "2023-05-18",
    method: "Bank Transfer",
    amount: "69.99",
    status: "Pending",
  },
]

const servicePlans = [
  {
    id: 1,
    name: "Basic Internet",
    description: "Essential internet for everyday browsing",
    price: "49.99",
    features: [
      "50 Mbps download speed",
      "10 Mbps upload speed",
      "Unlimited data",
      "Basic technical support",
      "Single device connection",
    ],
    customers: 450,
  },
  {
    id: 2,
    name: "Standard Internet",
    description: "Perfect for streaming and gaming",
    price: "79.99",
    features: [
      "250 Mbps download speed",
      "25 Mbps upload speed",
      "Unlimited data",
      "24/7 technical support",
      "Multiple device connection",
      "Free Wi-Fi router",
    ],
    customers: 850,
  },
  {
    id: 3,
    name: "Premium Fiber",
    description: "Ultra-fast fiber for power users",
    price: "129.99",
    features: [
      "1 Gbps download speed",
      "500 Mbps upload speed",
      "Unlimited data",
      "Priority technical support",
      "Multiple device connection",
      "Advanced Wi-Fi router",
      "Static IP address",
    ],
    customers: 650,
  },
  {
    id: 4,
    name: "Business Starter",
    description: "Reliable internet for small businesses",
    price: "149.99",
    features: [
      "500 Mbps download speed",
      "250 Mbps upload speed",
      "Unlimited data",
      "24/7 business support",
      "Multiple device connection",
      "Business Wi-Fi solution",
      "5 email accounts",
    ],
    customers: 220,
  },
  {
    id: 5,
    name: "Business Pro",
    description: "Enterprise-grade connectivity",
    price: "299.99",
    features: [
      "2 Gbps download speed",
      "1 Gbps upload speed",
      "Unlimited data",
      "Dedicated account manager",
      "VPN support",
      "Advanced security features",
      "10 email accounts",
      "99.9% uptime guarantee",
    ],
    customers: 180,
  },
]
