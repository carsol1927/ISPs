import type { Metadata } from "next"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, Check, CreditCard, Globe, MessageSquare, Save } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export const metadata: Metadata = {
  title: "Settings | ISP Management Portal",
  description: "Manage your ISP system settings",
}

export default function SettingsPage() {
  const invoice_number = "INV-001"
  const invoice_id = "INV-001"
  const amount = "100.00"
  const due_date = "2023-12-31"
  const date = "2023-12-25"
  const start_time = "09:00"
  const end_time = "17:00"

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your ISP system settings and configurations</p>
      </div>

      <Tabs defaultValue="company" className="w-full">
        <TabsList className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 mb-4">
          <TabsTrigger value="company">Company</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
          <TabsTrigger value="network">Network</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        {/* Company Profile Settings */}
        <TabsContent value="company" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Company Profile</CardTitle>
              <CardDescription>Manage your company information and branding</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="company-name">Company Name</Label>
                  <Input id="company-name" placeholder="Your ISP Name" defaultValue="FastConnect ISP" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-website">Website</Label>
                  <Input
                    id="company-website"
                    placeholder="https://example.com"
                    defaultValue="https://fastconnect.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-email">Email</Label>
                  <Input
                    id="company-email"
                    type="email"
                    placeholder="contact@example.com"
                    defaultValue="support@fastconnect.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-phone">Phone</Label>
                  <Input id="company-phone" placeholder="+1 (555) 123-4567" defaultValue="+1 (555) 987-6543" />
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="company-address">Address</Label>
                <Textarea
                  id="company-address"
                  placeholder="123 Main St, City, Country"
                  defaultValue="456 Tech Avenue, Silicon Valley, CA 94024"
                />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Business Hours</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="weekday-hours">Weekdays</Label>
                    <Input id="weekday-hours" placeholder="9:00 AM - 5:00 PM" defaultValue="8:00 AM - 6:00 PM" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weekend-hours">Weekends</Label>
                    <Input id="weekend-hours" placeholder="Closed" defaultValue="10:00 AM - 2:00 PM" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Company Logo</Label>
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 rounded border bg-muted flex items-center justify-center">
                    <Globe className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <Button variant="outline">Upload Logo</Button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Customer Portal Branding</CardTitle>
              <CardDescription>Customize how your customer portal looks</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="portal-title">Portal Title</Label>
                  <Input id="portal-title" placeholder="Customer Portal" defaultValue="FastConnect Customer Portal" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="portal-theme">Color Theme</Label>
                  <Select defaultValue="blue">
                    <SelectTrigger id="portal-theme">
                      <SelectValue placeholder="Select theme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="blue">Blue</SelectItem>
                      <SelectItem value="green">Green</SelectItem>
                      <SelectItem value="purple">Purple</SelectItem>
                      <SelectItem value="orange">Orange</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="portal-welcome">Welcome Message</Label>
                <Textarea
                  id="portal-welcome"
                  placeholder="Welcome to our customer portal"
                  defaultValue="Welcome to FastConnect Customer Portal. Manage your services, view invoices, and get support all in one place."
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="show-news" defaultChecked />
                <Label htmlFor="show-news">Show news and announcements</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="show-usage" defaultChecked />
                <Label htmlFor="show-usage">Show bandwidth usage statistics</Label>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Billing Settings */}
        <TabsContent value="billing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Invoice Settings</CardTitle>
              <CardDescription>Configure your invoice generation and delivery settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="invoice-prefix">Invoice Number Prefix</Label>
                  <Input id="invoice-prefix" placeholder="INV-" defaultValue="FC-INV-" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="invoice-start">Starting Invoice Number</Label>
                  <Input id="invoice-start" type="number" defaultValue="1001" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="invoice-due-days">Payment Due Days</Label>
                  <Input id="invoice-due-days" type="number" defaultValue="15" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="invoice-template">Invoice Template</Label>
                  <Select defaultValue="standard">
                    <SelectTrigger id="invoice-template">
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="detailed">Detailed</SelectItem>
                      <SelectItem value="minimal">Minimal</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="invoice-notes">Default Invoice Notes</Label>
                <Textarea
                  id="invoice-notes"
                  placeholder="Thank you for your business"
                  defaultValue="Thank you for choosing FastConnect ISP. Payment is due within 15 days of invoice date. Late payments may result in service interruption."
                />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Invoice Delivery</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="email-invoice" defaultChecked />
                  <Label htmlFor="email-invoice">Send invoices via email</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="sms-invoice-notification" defaultChecked />
                  <Label htmlFor="sms-invoice-notification">Send SMS notifications</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="portal-invoice" defaultChecked />
                  <Label htmlFor="portal-invoice">Make available in customer portal</Label>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment Gateways</CardTitle>
              <CardDescription>Configure payment methods and processors</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <CreditCard className="h-5 w-5" />
                    <Label>Credit Card Processor</Label>
                  </div>
                  <Switch id="cc-enabled" defaultChecked />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
                  <div className="space-y-2">
                    <Label htmlFor="cc-processor">Processor</Label>
                    <Select defaultValue="stripe">
                      <SelectTrigger id="cc-processor">
                        <SelectValue placeholder="Select processor" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="stripe">Stripe</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                        <SelectItem value="authorize">Authorize.net</SelectItem>
                        <SelectItem value="square">Square</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cc-api-key">API Key</Label>
                    <Input id="cc-api-key" type="password" value="••••••••••••••••" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Globe className="h-5 w-5" />
                    <Label>Bank Transfer</Label>
                  </div>
                  <Switch id="bank-enabled" defaultChecked />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
                  <div className="space-y-2">
                    <Label htmlFor="bank-name">Bank Name</Label>
                    <Input id="bank-name" defaultValue="First National Bank" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="account-number">Account Number</Label>
                    <Input id="account-number" defaultValue="XXXX-XXXX-XXXX-1234" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="h-5 w-5" />
                    <Label>Mobile Money</Label>
                  </div>
                  <Switch id="mobile-money-enabled" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
                  <div className="space-y-2">
                    <Label htmlFor="mobile-provider">Provider</Label>
                    <Select defaultValue="mpesa">
                      <SelectTrigger id="mobile-provider">
                        <SelectValue placeholder="Select provider" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mpesa">M-Pesa</SelectItem>
                        <SelectItem value="mtn">MTN Mobile Money</SelectItem>
                        <SelectItem value="airtel">Airtel Money</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mobile-api-key">API Key</Label>
                    <Input id="mobile-api-key" type="password" />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tax Settings</CardTitle>
              <CardDescription>Configure tax rates and rules</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="tax-enabled" defaultChecked />
                <Label htmlFor="tax-enabled">Enable tax calculation</Label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tax-name">Tax Name</Label>
                  <Input id="tax-name" defaultValue="VAT" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tax-rate">Default Tax Rate (%)</Label>
                  <Input id="tax-rate" type="number" defaultValue="18" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tax-number">Tax Registration Number</Label>
                  <Input id="tax-number" defaultValue="TAX-123456789" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tax-display">Display on Invoice</Label>
                  <Select defaultValue="itemized">
                    <SelectTrigger id="tax-display">
                      <SelectValue placeholder="Select display option" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="itemized">Itemized (per line)</SelectItem>
                      <SelectItem value="total">On total only</SelectItem>
                      <SelectItem value="both">Both</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Network Settings */}
        <TabsContent value="network" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>IP Management</CardTitle>
              <CardDescription>Configure IP pools and allocation settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>IP Pools</Label>
                <div className="rounded-md border">
                  <div className="grid grid-cols-5 p-3 font-medium border-b">
                    <div>Name</div>
                    <div>Network</div>
                    <div>Range</div>
                    <div>Used</div>
                    <div>Actions</div>
                  </div>
                  <div className="grid grid-cols-5 p-3 border-b">
                    <div>Main Pool</div>
                    <div>192.168.1.0/24</div>
                    <div>192.168.1.2 - 192.168.1.254</div>
                    <div>78/253</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 p-3 border-b">
                    <div>Business Pool</div>
                    <div>10.0.0.0/24</div>
                    <div>10.0.0.2 - 10.0.0.254</div>
                    <div>45/253</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 p-3">
                    <div>VIP Pool</div>
                    <div>172.16.0.0/24</div>
                    <div>172.16.0.2 - 172.16.0.254</div>
                    <div>12/253</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Add IP Pool
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>IP Assignment</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="dhcp-enabled" defaultChecked />
                  <Label htmlFor="dhcp-enabled">Use DHCP for automatic IP assignment</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="static-ip-option" defaultChecked />
                  <Label htmlFor="static-ip-option">Allow static IP assignment for customers</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="ip-validation" defaultChecked />
                  <Label htmlFor="ip-validation">Validate IP addresses against pools</Label>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Bandwidth Management</CardTitle>
              <CardDescription>Configure bandwidth allocation and traffic shaping</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Default Bandwidth Limits</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="default-download">Default Download (Mbps)</Label>
                    <Input id="default-download" type="number" defaultValue="10" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="default-upload">Default Upload (Mbps)</Label>
                    <Input id="default-upload" type="number" defaultValue="5" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Traffic Shaping</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="qos-enabled" defaultChecked />
                  <Label htmlFor="qos-enabled">Enable Quality of Service (QoS)</Label>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="burst-limit">Burst Limit (%)</Label>
                    <Input id="burst-limit" type="number" defaultValue="120" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="burst-time">Burst Time (seconds)</Label>
                    <Input id="burst-time" type="number" defaultValue="30" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Traffic Prioritization</Label>
                <div className="rounded-md border">
                  <div className="grid grid-cols-4 p-3 font-medium border-b">
                    <div>Traffic Type</div>
                    <div>Priority</div>
                    <div>Limit (%)</div>
                    <div>Actions</div>
                  </div>
                  <div className="grid grid-cols-4 p-3 border-b">
                    <div>VoIP</div>
                    <div>High</div>
                    <div>20%</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 p-3 border-b">
                    <div>Web Browsing</div>
                    <div>Medium</div>
                    <div>40%</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 p-3">
                    <div>File Sharing</div>
                    <div>Low</div>
                    <div>10%</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Add Traffic Rule
                </Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Network Monitoring</CardTitle>
              <CardDescription>Configure network monitoring thresholds and alerts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Monitoring Settings</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="enable-monitoring" defaultChecked />
                  <Label htmlFor="enable-monitoring">Enable network monitoring</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="enable-alerts" defaultChecked />
                  <Label htmlFor="enable-alerts">Enable alert notifications</Label>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="check-interval">Check Interval (minutes)</Label>
                    <Input id="check-interval" type="number" defaultValue="5" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="retry-count">Retry Count</Label>
                    <Input id="retry-count" type="number" defaultValue="3" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Alert Thresholds</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cpu-threshold">CPU Usage (%)</Label>
                    <Input id="cpu-threshold" type="number" defaultValue="80" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="memory-threshold">Memory Usage (%)</Label>
                    <Input id="memory-threshold" type="number" defaultValue="85" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bandwidth-threshold">Bandwidth Usage (%)</Label>
                    <Input id="bandwidth-threshold" type="number" defaultValue="90" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ping-threshold">Ping Response (ms)</Label>
                    <Input id="ping-threshold" type="number" defaultValue="100" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Alert Recipients</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="alert-emails">Email Addresses</Label>
                    <Input id="alert-emails" defaultValue="admin@fastconnect.com, noc@fastconnect.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="alert-phones">Phone Numbers (SMS)</Label>
                    <Input id="alert-phones" defaultValue="+1234567890, +0987654321" />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Email Notifications</CardTitle>
              <CardDescription>Configure email templates and delivery settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Email Server Configuration</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="smtp-server">SMTP Server</Label>
                    <Input id="smtp-server" defaultValue="smtp.gmail.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smtp-port">SMTP Port</Label>
                    <Input id="smtp-port" type="number" defaultValue="587" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smtp-username">Username</Label>
                    <Input id="smtp-username" defaultValue="notifications@fastconnect.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smtp-password">Password</Label>
                    <Input id="smtp-password" type="password" value="••••••••••••" />
                  </div>
                </div>
                <div className="flex items-center space-x-2 mt-2">
                  <Switch id="smtp-ssl" defaultChecked />
                  <Label htmlFor="smtp-ssl">Use SSL/TLS</Label>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Test Connection
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Email Templates</Label>
                <div className="rounded-md border">
                  <div className="grid grid-cols-4 p-3 font-medium border-b">
                    <div>Template</div>
                    <div>Subject</div>
                    <div>Status</div>
                    <div>Actions</div>
                  </div>
                  <div className="grid grid-cols-4 p-3 border-b">
                    <div>Welcome Email</div>
                    <div>Welcome to FastConnect ISP</div>
                    <div className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-1" />
                      Active
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 p-3 border-b">
                    <div>Invoice Notification</div>
                    <div>Your Invoice #{invoice_number} is Ready</div>
                    <div className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-1" />
                      Active
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 p-3 border-b">
                    <div>Payment Reminder</div>
                    <div>Payment Reminder for Invoice #{invoice_number}</div>
                    <div className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-1" />
                      Active
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 p-3">
                    <div>Service Interruption</div>
                    <div>Important: Service Interruption Notice</div>
                    <div className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-1" />
                      Active
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Add Template
                </Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>SMS Notifications</CardTitle>
              <CardDescription>Configure SMS gateway and message templates</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>SMS Gateway Configuration</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sms-provider">SMS Provider</Label>
                    <Select defaultValue="twilio">
                      <SelectTrigger id="sms-provider">
                        <SelectValue placeholder="Select provider" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="twilio">Twilio</SelectItem>
                        <SelectItem value="nexmo">Nexmo (Vonage)</SelectItem>
                        <SelectItem value="africastalking">Africa's Talking</SelectItem>
                        <SelectItem value="custom">Custom API</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sms-sender-id">Sender ID</Label>
                    <Input id="sms-sender-id" defaultValue="FastConnect" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sms-api-key">API Key</Label>
                    <Input id="sms-api-key" type="password" value="••••••••••••••••" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sms-api-secret">API Secret</Label>
                    <Input id="sms-api-secret" type="password" value="••••••••••••••••" />
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Test SMS Gateway
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>SMS Templates</Label>
                <div className="rounded-md border">
                  <div className="grid grid-cols-3 p-3 font-medium border-b">
                    <div>Template</div>
                    <div>Message</div>
                    <div>Actions</div>
                  </div>
                  <div className="grid grid-cols-3 p-3 border-b">
                    <div>Payment Reminder</div>
                    <div>
                      FastConnect: Your invoice #{invoice_id} of {amount} is due on {due_date}. Please make payment to
                      avoid service interruption.
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 p-3 border-b">
                    <div>Payment Confirmation</div>
                    <div>
                      FastConnect: Thank you! We've received your payment of {amount} for invoice #{invoice_id}.
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 p-3">
                    <div>Service Notification</div>
                    <div>
                      FastConnect: We'll be performing maintenance on {date} from {start_time} to {end_time}. Service
                      may be interrupted.
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Add Template
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>SMS Notification Events</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="sms-invoice" defaultChecked />
                    <Label htmlFor="sms-invoice">New invoice generated</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sms-payment" defaultChecked />
                    <Label htmlFor="sms-payment">Payment received</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sms-reminder" defaultChecked />
                    <Label htmlFor="sms-reminder">Payment reminder</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sms-service" defaultChecked />
                    <Label htmlFor="sms-service">Service interruption</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sms-maintenance" defaultChecked />
                    <Label htmlFor="sms-maintenance">Scheduled maintenance</Label>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>System Notifications</CardTitle>
              <CardDescription>Configure internal notifications for staff</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Admin Notification Settings</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="notify-new-customer" defaultChecked />
                    <Label htmlFor="notify-new-customer">New customer registration</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="notify-large-payment" defaultChecked />
                    <Label htmlFor="notify-large-payment">Large payments (over threshold)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="notify-failed-payment" defaultChecked />
                    <Label htmlFor="notify-failed-payment">Failed payment attempts</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="notify-support-ticket" defaultChecked />
                    <Label htmlFor="notify-support-ticket">New support tickets</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="notify-system-error" defaultChecked />
                    <Label htmlFor="notify-system-error">System errors</Label>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Notification Channels</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="channel-email" defaultChecked />
                    <Label htmlFor="channel-email">Email</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="channel-sms" />
                    <Label htmlFor="channel-sms">SMS</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="channel-dashboard" defaultChecked />
                    <Label htmlFor="channel-dashboard">Dashboard alerts</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="channel-browser" defaultChecked />
                    <Label htmlFor="channel-browser">Browser notifications</Label>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="large-payment-threshold">Large Payment Threshold</Label>
                <div className="flex items-center space-x-2">
                  <Input id="large-payment-threshold" type="number" defaultValue="1000" />
                  <Select defaultValue="usd">
                    <SelectTrigger className="w-24">
                      <SelectValue placeholder="Currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="usd">USD</SelectItem>
                      <SelectItem value="eur">EUR</SelectItem>
                      <SelectItem value="gbp">GBP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Integrations Settings */}
        <TabsContent value="integrations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Mikrotik Integration</CardTitle>
              <CardDescription>Configure Mikrotik RouterOS API integration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Default Mikrotik Connection</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="mikrotik-host">Host/IP Address</Label>
                    <Input id="mikrotik-host" defaultValue="192.168.1.1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mikrotik-port">API Port</Label>
                    <Input id="mikrotik-port" type="number" defaultValue="8728" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mikrotik-username">Username</Label>
                    <Input id="mikrotik-username" defaultValue="admin" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mikrotik-password">Password</Label>
                    <Input id="mikrotik-password" type="password" value="••••••••••••" />
                  </div>
                </div>
                <div className="flex items-center space-x-2 mt-2">
                  <Switch id="mikrotik-ssl" />
                  <Label htmlFor="mikrotik-ssl">Use SSL (API-SSL)</Label>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Test Connection
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>API Integration Settings</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="mikrotik-auto-sync" defaultChecked />
                    <Label htmlFor="mikrotik-auto-sync">Auto-sync customer data with Mikrotik</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="mikrotik-auto-provision" defaultChecked />
                    <Label htmlFor="mikrotik-auto-provision">Auto-provision new customers</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="mikrotik-auto-suspend" defaultChecked />
                    <Label htmlFor="mikrotik-auto-suspend">Auto-suspend delinquent customers</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="mikrotik-auto-resume" defaultChecked />
                    <Label htmlFor="mikrotik-auto-resume">Auto-resume service after payment</Label>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Mikrotik Sync Schedule</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="mikrotik-sync-interval">Sync Interval (minutes)</Label>
                    <Input id="mikrotik-sync-interval" type="number" defaultValue="30" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mikrotik-retry-attempts">Retry Attempts</Label>
                    <Input id="mikrotik-retry-attempts" type="number" defaultValue="3" />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Accounting Integration</CardTitle>
              <CardDescription>Configure integration with accounting software</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Accounting Software</Label>
                <Select defaultValue="quickbooks">
                  <SelectTrigger id="accounting-software">
                    <SelectValue placeholder="Select accounting software" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="quickbooks">QuickBooks</SelectItem>
                    <SelectItem value="xero">Xero</SelectItem>
                    <SelectItem value="sage">Sage</SelectItem>
                    <SelectItem value="freshbooks">FreshBooks</SelectItem>
                    <SelectItem value="none">None</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>QuickBooks Integration</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="qb-client-id">Client ID</Label>
                    <Input id="qb-client-id" defaultValue="ABCDEfghijklmnopqrstuvwxyz" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="qb-client-secret">Client Secret</Label>
                    <Input id="qb-client-secret" type="password" value="••••••••••••••••" />
                  </div>
                </div>
                <div className="flex items-center space-x-2 mt-2">
                  <Switch id="qb-sandbox" />
                  <Label htmlFor="qb-sandbox">Use Sandbox Environment</Label>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Authorize QuickBooks
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Sync Settings</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="sync-customers" defaultChecked />
                    <Label htmlFor="sync-customers">Sync customers</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sync-invoices" defaultChecked />
                    <Label htmlFor="sync-invoices">Sync invoices</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sync-payments" defaultChecked />
                    <Label htmlFor="sync-payments">Sync payments</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sync-expenses" />
                    <Label htmlFor="sync-expenses">Sync expenses</Label>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Sync Schedule</Label>
                <Select defaultValue="daily">
                  <SelectTrigger id="sync-schedule">
                    <SelectValue placeholder="Select sync schedule" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="manual">Manual Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>API Integration</CardTitle>
              <CardDescription>Configure API access for third-party integrations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>API Access</Label>
                  <Switch id="enable-api" defaultChecked />
                </div>
                <p className="text-sm text-muted-foreground">
                  Enable API access to allow third-party applications to connect to your ISP management system.
                </p>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>API Keys</Label>
                <div className="rounded-md border">
                  <div className="grid grid-cols-4 p-3 font-medium border-b">
                    <div>Name</div>
                    <div>Key</div>
                    <div>Created</div>
                    <div>Actions</div>
                  </div>
                  <div className="grid grid-cols-4 p-3 border-b">
                    <div>Monitoring System</div>
                    <div>••••••••••••••••••••••••</div>
                    <div>2023-05-15</div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                      <Button variant="ghost" size="sm">
                        Revoke
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 p-3">
                    <div>Mobile App</div>
                    <div>••••••••••••••••••••••••</div>
                    <div>2023-06-22</div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                      <Button variant="ghost" size="sm">
                        Revoke
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Generate New API Key
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>API Rate Limiting</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="rate-limit">Requests per minute</Label>
                    <Input id="rate-limit" type="number" defaultValue="60" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="rate-limit-burst">Burst limit</Label>
                    <Input id="rate-limit-burst" type="number" defaultValue="100" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Webhook Endpoints</Label>
                <div className="rounded-md border">
                  <div className="grid grid-cols-3 p-3 font-medium border-b">
                    <div>Event</div>
                    <div>URL</div>
                    <div>Actions</div>
                  </div>
                  <div className="grid grid-cols-3 p-3 border-b">
                    <div>payment.received</div>
                    <div>https://example.com/webhooks/payments</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 p-3">
                    <div>customer.created</div>
                    <div>https://example.com/webhooks/customers</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Add Webhook Endpoint
                </Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Users Settings */}
        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>Manage staff accounts and permissions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Staff Accounts</Label>
                <div className="rounded-md border">
                  <div className="grid grid-cols-5 p-3 font-medium border-b">
                    <div>Name</div>
                    <div>Email</div>
                    <div>Role</div>
                    <div>Status</div>
                    <div>Actions</div>
                  </div>
                  <div className="grid grid-cols-5 p-3 border-b">
                    <div>John Doe</div>
                    <div>john@fastconnect.com</div>
                    <div>Administrator</div>
                    <div className="text-green-500">Active</div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm">
                        Disable
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 p-3 border-b">
                    <div>Jane Smith</div>
                    <div>jane@fastconnect.com</div>
                    <div>Billing Manager</div>
                    <div className="text-green-500">Active</div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm">
                        Disable
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 p-3">
                    <div>Mike Johnson</div>
                    <div>mike@fastconnect.com</div>
                    <div>Support Agent</div>
                    <div className="text-green-500">Active</div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm">
                        Disable
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Add User
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>User Roles</Label>
                <div className="rounded-md border">
                  <div className="grid grid-cols-3 p-3 font-medium border-b">
                    <div>Role</div>
                    <div>Description</div>
                    <div>Actions</div>
                  </div>
                  <div className="grid grid-cols-3 p-3 border-b">
                    <div>Administrator</div>
                    <div>Full access to all system features</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 p-3 border-b">
                    <div>Billing Manager</div>
                    <div>Manage invoices, payments, and financial reports</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 p-3 border-b">
                    <div>Support Agent</div>
                    <div>Handle customer support tickets and inquiries</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 p-3">
                    <div>Network Technician</div>
                    <div>Manage network devices and configurations</div>
                    <div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Add Role
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Default Permissions</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="perm-view-dashboard" defaultChecked />
                    <Label htmlFor="perm-view-dashboard">View dashboard</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="perm-manage-customers" defaultChecked />
                    <Label htmlFor="perm-manage-customers">Manage customers</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="perm-manage-billing" defaultChecked />
                    <Label htmlFor="perm-manage-billing">Manage billing</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="perm-manage-services" defaultChecked />
                    <Label htmlFor="perm-manage-services">Manage services</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="perm-manage-network" defaultChecked />
                    <Label htmlFor="perm-manage-network">Manage network</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="perm-manage-settings" />
                    <Label htmlFor="perm-manage-settings">Manage settings</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="perm-view-reports" defaultChecked />
                    <Label htmlFor="perm-view-reports">View reports</Label>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Activity Logging</CardTitle>
              <CardDescription>Configure user activity logging and audit trails</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Activity Logging</Label>
                  <Switch id="enable-logging" defaultChecked />
                </div>
                <p className="text-sm text-muted-foreground">Track user actions for security and compliance purposes</p>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Log Retention</Label>
                <Select defaultValue="90">
                  <SelectTrigger id="log-retention">
                    <SelectValue placeholder="Select retention period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="60">60 days</SelectItem>
                    <SelectItem value="90">90 days</SelectItem>
                    <SelectItem value="180">180 days</SelectItem>
                    <SelectItem value="365">1 year</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Events to Log</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="log-login" defaultChecked />
                    <Label htmlFor="log-login">User login/logout</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="log-customer" defaultChecked />
                    <Label htmlFor="log-customer">Customer data changes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="log-billing" defaultChecked />
                    <Label htmlFor="log-billing">Billing operations</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="log-settings" defaultChecked />
                    <Label htmlFor="log-settings">Settings changes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="log-network" defaultChecked />
                    <Label htmlFor="log-network">Network configuration changes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="log-api" defaultChecked />
                    <Label htmlFor="log-api">API access</Label>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Authentication Settings</CardTitle>
              <CardDescription>Configure authentication methods and security policies</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Password Policy</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="password-complexity" defaultChecked />
                    <Label htmlFor="password-complexity">Enforce password complexity</Label>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
                    <div className="space-y-2">
                      <Label htmlFor="min-length">Minimum length</Label>
                      <Input id="min-length" type="number" defaultValue="8" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="max-age">Maximum age (days)</Label>
                      <Input id="max-age" type="number" defaultValue="90" />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="require-uppercase" defaultChecked />
                    <Label htmlFor="require-uppercase">Require uppercase letters</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="require-lowercase" defaultChecked />
                    <Label htmlFor="require-lowercase">Require lowercase letters</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="require-numbers" defaultChecked />
                    <Label htmlFor="require-numbers">Require numbers</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="require-special" defaultChecked />
                    <Label htmlFor="require-special">Require special characters</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="prevent-reuse" defaultChecked />
                    <Label htmlFor="prevent-reuse">Prevent password reuse</Label>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Two-Factor Authentication</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="enable-2fa" defaultChecked />
                    <Label htmlFor="enable-2fa">Enable two-factor authentication</Label>
                  </div>
                  <div className="flex items-center space-x-2 pl-7">
                    <Switch id="require-2fa-staff" defaultChecked />
                    <Label htmlFor="require-2fa-staff">Require for staff accounts</Label>
                  </div>
                  <div className="flex items-center space-x-2 pl-7">
                    <Switch id="require-2fa-customers" />
                    <Label htmlFor="require-2fa-customers">Require for customer accounts</Label>
                  </div>
                </div>
                <div className="space-y-2 mt-2">
                  <Label>2FA Methods</Label>
                  <div className="flex items-center space-x-2">
                    <Switch id="2fa-app" defaultChecked />
                    <Label htmlFor="2fa-app">Authenticator app</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="2fa-sms" defaultChecked />
                    <Label htmlFor="2fa-sms">SMS</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="2fa-email" defaultChecked />
                    <Label htmlFor="2fa-email">Email</Label>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Session Management</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="session-timeout">Session timeout (minutes)</Label>
                    <Input id="session-timeout" type="number" defaultValue="30" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="max-sessions">Maximum concurrent sessions</Label>
                    <Input id="max-sessions" type="number" defaultValue="3" />
                  </div>
                </div>
                <div className="flex items-center space-x-2 mt-2">
                  <Switch id="force-logout" defaultChecked />
                  <Label htmlFor="force-logout">Force logout on password change</Label>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Access Control</CardTitle>
              <CardDescription>Configure IP restrictions and access controls</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>IP Restrictions</Label>
                  <Switch id="enable-ip-restrictions" />
                </div>
                <p className="text-sm text-muted-foreground">Restrict access to the system based on IP addresses</p>
              </div>

              <div className="space-y-2">
                <Label>Allowed IP Addresses</Label>
                <Textarea placeholder="Enter IP addresses or CIDR ranges, one per line" className="h-24" />
                <p className="text-xs text-muted-foreground">Example: 192.168.1.0/24, 10.0.0.5</p>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Login Attempts</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="max-attempts">Maximum failed attempts</Label>
                    <Input id="max-attempts" type="number" defaultValue="5" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lockout-duration">Lockout duration (minutes)</Label>
                    <Input id="lockout-duration" type="number" defaultValue="30" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Suspicious Activity Detection</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="detect-suspicious" defaultChecked />
                  <Label htmlFor="detect-suspicious">Enable suspicious activity detection</Label>
                </div>
                <div className="flex items-center space-x-2 pl-7">
                  <Switch id="notify-suspicious" defaultChecked />
                  <Label htmlFor="notify-suspicious">Notify administrators</Label>
                </div>
                <div className="flex items-center space-x-2 pl-7">
                  <Switch id="block-suspicious" defaultChecked />
                  <Label htmlFor="block-suspicious">Automatically block suspicious activity</Label>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Data Security</CardTitle>
              <CardDescription>Configure data encryption and security settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Data Encryption</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="encrypt-data-at-rest" defaultChecked />
                  <Label htmlFor="encrypt-data-at-rest">Encrypt sensitive data at rest</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="encrypt-backups" defaultChecked />
                  <Label htmlFor="encrypt-backups">Encrypt backups</Label>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Customer Data Protection</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="mask-cc" defaultChecked />
                  <Label htmlFor="mask-cc">Mask credit card numbers</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="mask-ssn" defaultChecked />
                  <Label htmlFor="mask-ssn">Mask national ID/SSN</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="encrypt-passwords" defaultChecked />
                  <Label htmlFor="encrypt-passwords">Encrypt passwords with strong hashing</Label>
                </div>
              </div>

              <Separator />

              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Security Recommendation</AlertTitle>
                <AlertDescription>
                  We recommend enabling all encryption options to ensure maximum data security and compliance with data
                  protection regulations.
                </AlertDescription>
              </Alert>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* System Settings */}
        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>System Maintenance</CardTitle>
              <CardDescription>Configure system maintenance and backup settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Automated Backups</Label>
                <div className="flex items-center space-x-2">
                  <Switch id="enable-backups" defaultChecked />
                  <Label htmlFor="enable-backups">Enable automated backups</Label>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="backup-frequency">Backup Frequency</Label>
                    <Select defaultValue="daily">
                      <SelectTrigger id="backup-frequency">
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="backup-retention">Retention Period</Label>
                    <Select defaultValue="30">
                      <SelectTrigger id="backup-retention">
                        <SelectValue placeholder="Select retention" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="7">7 days</SelectItem>
                        <SelectItem value="14">14 days</SelectItem>
                        <SelectItem value="30">30 days</SelectItem>
                        <SelectItem value="90">90 days</SelectItem>
                        <SelectItem value="365">1 year</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Backup Storage</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="local-backup" defaultChecked />
                    <Label htmlFor="local-backup">Local storage</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="cloud-backup" defaultChecked />
                    <Label htmlFor="cloud-backup">Cloud storage</Label>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
                    <div className="space-y-2">
                      <Label htmlFor="cloud-provider">Cloud Provider</Label>
                      <Select defaultValue="aws">
                        <SelectTrigger id="cloud-provider">
                          <SelectValue placeholder="Select provider" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="aws">Amazon S3</SelectItem>
                          <SelectItem value="gcp">Google Cloud Storage</SelectItem>
                          <SelectItem value="azure">Azure Blob Storage</SelectItem>
                          <SelectItem value="dropbox">Dropbox</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cloud-bucket">Bucket/Container</Label>
                      <Input id="cloud-bucket" defaultValue="fastconnect-backups" />
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Test Backup Connection
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Database Maintenance</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="db-optimization" defaultChecked />
                    <Label htmlFor="db-optimization">Automatic database optimization</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="db-cleanup" defaultChecked />
                    <Label htmlFor="db-cleanup">Automatic cleanup of old data</Label>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
                    <div className="space-y-2">
                      <Label htmlFor="cleanup-logs">Logs older than (days)</Label>
                      <Input id="cleanup-logs" type="number" defaultValue="90" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cleanup-temp">Temporary data older than (days)</Label>
                      <Input id="cleanup-temp" type="number" defaultValue="7" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>System Updates</CardTitle>
              <CardDescription>Configure system update settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Update Settings</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="auto-updates" defaultChecked />
                    <Label htmlFor="auto-updates">Automatic updates</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="update-notification" defaultChecked />
                    <Label htmlFor="update-notification">Notify before updates</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="update-backup" defaultChecked />
                    <Label htmlFor="update-backup">Backup before updates</Label>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Update Schedule</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="update-day">Preferred Day</Label>
                    <Select defaultValue="sunday">
                      <SelectTrigger id="update-day">
                        <SelectValue placeholder="Select day" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monday">Monday</SelectItem>
                        <SelectItem value="tuesday">Tuesday</SelectItem>
                        <SelectItem value="wednesday">Wednesday</SelectItem>
                        <SelectItem value="thursday">Thursday</SelectItem>
                        <SelectItem value="friday">Friday</SelectItem>
                        <SelectItem value="saturday">Saturday</SelectItem>
                        <SelectItem value="sunday">Sunday</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="update-time">Preferred Time</Label>
                    <Select defaultValue="02:00">
                      <SelectTrigger id="update-time">
                        <SelectValue placeholder="Select time" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="00:00">12:00 AM</SelectItem>
                        <SelectItem value="01:00">1:00 AM</SelectItem>
                        <SelectItem value="02:00">2:00 AM</SelectItem>
                        <SelectItem value="03:00">3:00 AM</SelectItem>
                        <SelectItem value="04:00">4:00 AM</SelectItem>
                        <SelectItem value="22:00">10:00 PM</SelectItem>
                        <SelectItem value="23:00">11:00 PM</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Current System Version</Label>
                <div className="rounded-md border p-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="text-sm font-medium">Version:</div>
                    <div className="text-sm">3.5.2</div>
                    <div className="text-sm font-medium">Last Updated:</div>
                    <div className="text-sm">2023-07-15</div>
                    <div className="text-sm font-medium">Status:</div>
                    <div className="text-sm text-green-500">Up to date</div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Check for Updates
                </Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>System Performance</CardTitle>
              <CardDescription>Configure system performance settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Cache Settings</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="enable-cache" defaultChecked />
                    <Label htmlFor="enable-cache">Enable system cache</Label>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
                    <div className="space-y-2">
                      <Label htmlFor="cache-ttl">Cache TTL (minutes)</Label>
                      <Input id="cache-ttl" type="number" defaultValue="60" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cache-size">Maximum Cache Size (MB)</Label>
                      <Input id="cache-size" type="number" defaultValue="512" />
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="mt-2">
                    Clear Cache
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Queue Settings</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="enable-queue" defaultChecked />
                    <Label htmlFor="enable-queue">Enable job queue</Label>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
                    <div className="space-y-2">
                      <Label htmlFor="queue-workers">Number of Workers</Label>
                      <Input id="queue-workers" type="number" defaultValue="3" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="queue-retry">Max Retry Attempts</Label>
                      <Input id="queue-retry" type="number" defaultValue="5" />
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Resource Limits</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="memory-limit">Memory Limit (MB)</Label>
                    <Input id="memory-limit" type="number" defaultValue="1024" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="execution-timeout">Execution Timeout (seconds)</Label>
                    <Input id="execution-timeout" type="number" defaultValue="30" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="upload-limit">Upload Size Limit (MB)</Label>
                    <Input id="upload-limit" type="number" defaultValue="50" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="request-limit">Request Rate Limit (per minute)</Label>
                    <Input id="request-limit" type="number" defaultValue="100" />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
